// 图片前缀
function prefix(){
    var URLINDEX="http://m.jiumaojia.com/views/mobile/skin/default/image";
    return URLINDEX;
}
function getCode(){
  var code="f1be2b8c4b837fe9c49afef030ff9765";
  return code;
}
function preUrl(){
  var url="http://m.jiumaojia.com";
  return url
}
module.exports = {
  prefix:prefix,
  code:getCode,
  pre:preUrl
}
