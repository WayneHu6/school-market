// pages/course/course.js
import { request } from "../../request/request";


Page({

  /**
   * 页面的初始数据
   */
  data: {
    
    value: "",
    productAskBuy:[],
    forumCampusEverday:[],
    products:[],
    forums:[],
    imgUrls: [
      "https://images.unsplash.com/photo-1551334787-21e6bd3ab135?w=640",
      "https://images.unsplash.com/photo-1551214012-84f95e060dee?w=640",
      "https://images.unsplash.com/photo-1551446591-142875a901a1?w=640"
    ],
    indicatorDots: false,
    autoplay: true,
    interval: 5000,
    duration: 1000,
    listCourse:['全部','求购专区','帖子专区','校园日常'],
    tabIndex:0,
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getProductAskBuyData();
    this.getForumCampusEverday();
    this.getForums();
    this.getProducts();

  },

  
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  onShow: function(){
    this.getProductAskBuyData();
    this.getForumCampusEverday();
    this.getForums();
    this.getProducts();
  },

    //此为搜索相关的函数
    inputfocus:function(e){
      console.log(e);
      wx.navigateTo({
      url: "../search/search"
      })
    },

  clickTab(e) {
    console.log(e);
    this.setData({
      tabIndex: e.detail
    });
  },
  moreCourse:function(){
    console.log("123");
    wx.navigateTo({
      url: "/pages/course-list/course-list"
    });
  },
  goCourseDetail:function(){
    wx.navigateTo({
      url: "/pages/course-detail/course-detail"
    });
  },
// 获取求购商品信息的方法
getProductAskBuyData(){
  request({url:"/goods/getByType?type=求购信息",data:{"key":"asjkdhasdjk"}})
  .then(result=>{
    this.setData({
      productAskBuy:result.data
    })
  })
},
// 获取校园日常帖子的方法
getForumCampusEverday(){
  request({url:"/forum/getByType?type=校园日常",data:{"key":"asjkdhasdjk"}})
  .then(result=>{
    this.setData({
      forumCampusEverday:result.data
    })
  })
},

// 获取所有论坛帖子的方法
getForums(){
  request({url:"/forum/list",data:{"key":"asjkdhasdjk"}})
  .then(result=>{
    this.setData({
      forums:result.data
    })
  })
},

// 获取所有商品的方法
getProducts(){
  request({url:"/goods/list",data:{"key":"asjkdhasdjk"}})
  .then(result=>{
    this.setData({
      products:result.data
    })
  })
},

// 跳转到发布论坛信息的界面
gotoRelease(){
  wx.navigateTo({
    url: '/pages/sned-forum/sned-forum',
  })
},
// 跳转到首页的界面
setDisabled(){
  wx.switchTab({
    url: '../../pages/index/index',
  })
},






})