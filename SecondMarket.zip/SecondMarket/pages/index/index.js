//index.js
import { request } from "../../request/request";

//获取应用实例
var app = getApp();
var util = require('../../common/common.js');
console.log(util);
let URLINDEX=util.prefix();
Page({
  data: {
    "swiperDatas":[],
    userInfo: {},
    // 此为搜索的数据
    src:{
      img1:URLINDEX+"/jmj/new_active/index/leftear.png",
      img2:URLINDEX+"/jmj/new_active/index/rightear.png",
      img3:URLINDEX+"/jmj/new_active/index/flower.png",
      img4:URLINDEX+"/jmj/new_active/index/search.png"
    },
    //此为顶部导航的数据
    navState:1,
    class1:"headItem",
    class2:"headItem active",
    headnav:[
      {
        name:'首页',
        img:URLINDEX+"/jmj/icon/page1_bg1.png",
        url:'../index/index?id=0'
      },{
        name:'二手甩卖',
        img:URLINDEX+"/jmj/icon/page1_bg2.png",
        url:'../prolist/prolist?id=1'
      },{
        name:'求购信息',
        img:URLINDEX+"/jmj/icon/page1_bg3.png",
        url:'../prolist/prolist?id=2'
      },
    ],
    banner:[],
    menu:[],
    notice:[],
    cate:[],
    products:[],
    page:1,
    // 首页专辑列表的数据
    fimgimg:URLINDEX+"/jmj/icon/like-ed.png",
    ufimgimg:URLINDEX+"/jmj/icon/like.png",
    imgLook:URLINDEX+"/jmj/icon/read.png",
    cateList:[],
    lodding:true,
  },
 
  //此为搜索相关的函数
    inputfocus:function(e){
      console.log(e);
      wx.navigateTo({
      url: "../search/search"
      })
    },
  //头部nav点击事件函数
  changeNavState: function(e){
    console.log(e);
    var item=e.currentTarget.dataset.item;
    var key=e.currentTarget.dataset.key;
    console.log(key);
    wx.navigateTo({
      url: item.url
    })
  },


  //获取窗口的高度
   onShow: function( e ) {
    wx.getSystemInfo( {
      success: ( res ) => {
        this.setData( {
          windowHeight: res.windowHeight,
          windowWidth: res.windowWidth
        })
      }
    });

    this.getSwiperData();
    this.getMenuData();
    this.getNoticeData();
    this.getGoodsData();


  },

  onPullDownRefresh: function(){
    this.getSwiperData();
    this.getMenuData();
    this.getNoticeData();
    this.getGoodsData();
  },
  onLoad: function () {
    var that = this
    //调用应用实例的方法获取全局数据
    app.getUserInfo(function(userInfo){
      //更新数据
      that.setData({
        userInfo:userInfo
      })
    })
    
    this.getSwiperData();
    this.getMenuData();
    this.getNoticeData();
    this.getGoodsData();

    console.log(this.data.userInfo)

  },

  // 跳转到查看更多公告通知页面
  moreCourse(){
    wx.navigateTo({
      url: '/pages/notice-list/notice-list'
    })
  },
  
// 获取轮播图的方法
getSwiperData(){
  request({url:"/banner/list",data:{"key":"asjkdhasdjk"}})
  .then(result=>{
    this.setData({
      banner:result.data
    })
  })
  
},
// 获取菜单的方法
getMenuData(){
  request({url:"/menu/list",data:{"key":"asjkdhasdjk"}})
  .then(result=>{
    this.setData({
      menu:result.data
    })
  })
},
// 获取通知公告的方法
getNoticeData(){
  request({url:"/notice/list",data:{"key":"asjkdhasdjk"}})
  .then(result=>{
    this.setData({
      notice:result.data
    })
  })
},
// 查看通知公告详情的方法
goNoticeDetail(d){
  console.log(d);
  // 将数据传过去
  wx.setStorageSync('noticeInfo', d.target.dataset.info);
  wx.navigateTo({
    url: '../notice-detail/notice-detail'
  })
},
// 获取热门商品的方法
getGoodsData(){
  request({url:"/goods/list",data:{"key":"asjkdhasdjk"}})
  .then(result=>{
    this.setData({
      products:result.data
    })
  })
},
// 查看商品详情
navigateToProduct(event) {
  var productId = event.currentTarget.dataset.goodsId;
  wx.navigateTo({
  url: '../products/products?id=' + productId
  });
},




});



