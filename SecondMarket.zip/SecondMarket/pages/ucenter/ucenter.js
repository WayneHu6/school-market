var util = require('../../common/common.js');
let URLINDEX=util.prefix();
Page({
  data:{
    userinfo:{},
    img_bg:"/images/18.png",
    order_gaid:[
      {
        state:"待付款",
        img:"../../images/1.png",
        id:1
      },
      {
        state:"待发货",
        img:"../../images/2.png",
        id:2
      },
      {
        state:"待收货",
        img:"../../images/3.png",
        id:3
      },
      {
        state:"已完成",
        img:"../../images/4.png",
        id:4
      },
    ],
    line1:[
      {
        name:"我的收藏",
        img:"../../images/5.png",
        id:1,
        url:"/pages/u-collect/u-collect"
      },
      {
        name:"我的发布",
        img:"../../images/6.png",
        id:2,
        url:"/pages/u-sned-forum/u-sned-forum"
      },
      {
        name:"个人信息",
        img:"../../images/7.png",
        id:3,
        url:"/pages/u-edit-info/u-edit-info"
      },
      {
        name:"收货地址",
        img:"../../images/8.png",
        id:4,
        url:"/pages/address/address"
      }
    ],
    line2:[
       {
        name:"购物车",
        img:"../../images/9.png",
        id:1,
        url:"/pages/cart/cart",
      },
      {
        name:"关于本平台",
        img:"../../images/22.png",
        id:2,
        url:"/pages/agreement/agreement"
      },
      {
        name:"联系合作",
        img:"../../images/13.png",
        url:"/pages/u-custom/u-custom",
        id:3
      },
      {
        name:"退出登录",
        img:"../../images/12.png",
        id:4
      }
    ]
  },
  onLoad:function(options){
    // 加载用户信息
    this.setData({
      userinfo:wx.getStorageSync("userinfo")
    });
  },
  onReady:function(){
    // 页面渲染完成
  },
  onShow:function(){
    // 页面显示
     // 加载用户信息
     this.setData({
      userinfo:wx.getStorageSync("userinfo")
    });
    console.log(this.data.userInfo)
  },
  onHide:function(){
    // 页面隐藏
  },
  onUnload:function(){
    // 页面关闭
  },
  // 退出登录
  exitLogin(){
    wx.clearStorageSync();
    wx.redirectTo({
      url: '../login/login',
    })
  }



})