// pages/course/course.js
import { request } from "../../request/request";


Page({

  /**
   * 页面的初始数据
   */
  data: {
    value: "",
    collects:[],
    imgUrls: [
      "https://images.unsplash.com/photo-1551334787-21e6bd3ab135?w=640",
      "https://images.unsplash.com/photo-1551214012-84f95e060dee?w=640",
      "https://images.unsplash.com/photo-1551446591-142875a901a1?w=640"
    ],
    indicatorDots: false,
    autoplay: true,
    interval: 5000,
    duration: 1000,
    listCourse:['全部','求购专区','帖子专区','校园日常'],
    tabIndex:0,
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getForums();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },
  clickTab(e) {
    console.log(e);
    this.setData({
      tabIndex: e.detail
    });
  },
  moreCourse:function(){
    console.log("123");
    wx.navigateTo({
      url: "/pages/course-list/course-list"
    });
  },
  goCourseDetail:function(){
    wx.navigateTo({
      url: "/pages/course-detail/course-detail"
    });
  },



// 获取我的论坛帖子的方法
getForums(){
  request({url:"/collect/getByUserId?userid="+wx.getStorageSync('userinfo').id,data:{"key":"asjkdhasdjk"}})
  .then(result=>{
    this.setData({
      collects:result.data
    })
  })
},
delForum(d){
  console.log(d);
  var id = d.currentTarget.dataset.id;
  request({url:"/collect/del?id="+id,data:{"key":"asjkdhasdjk"}})
  .then(result=>{
    this.getForums();
  })
},



// 跳转到发布论坛信息的界面
gotoRelease(){
  wx.navigateTo({
    url: '/pages/sned-forum/sned-forum',
  })
},






})