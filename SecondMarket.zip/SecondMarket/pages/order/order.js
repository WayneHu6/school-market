// pages/order/order.js
var util = require('../../common/common.js');
let URLINDEX = util.prefix();

import {
  request
} from "../../request/request";

Page({
  data: {
    empty: {
      emptyCat: URLINDEX + "/jmj/icon/cat_car.png",
      text: "暂无订单消息哦"
    },
    class1: "item active",
    class2: "item",
    page: 0,
    orderState: [{
        id: 0,
        state: "全部订单"
      },
      {
        id: 1,
        state: "待支付"
      },
      {
        id: 2,
        state: "待发货"
      },
      {
        id: 3,
        state: "待收货"
      },
      {
        id: 4,
        state: "已完成"
      }
    ]
  },
  changeState: function (e) {
    var index = e.currentTarget.dataset.index;
    this.setData({
      id: index,
      page: 0,
      orderList: this.data.orderList
    })
  },
  onLoad: function (options) {
    var that = this;
    this.setData({
      id: options.cid
    });
    wx.setNavigationBarTitle({
      title: options.title
    });
    getOrder(that, wx.getStorageSync('userinfo').id);
  },
  onShow: function () {
    getOrder(that, wx.getStorageSync('userinfo').id);
    
  },

  // 确认收货的方法
  goConfirmOrders(d) {
    // console.log(d);
    var id = d.target.dataset.info;
    request({
        url: "/orders/confirmOrders",
        data: {
          "id": id
        }
      })
      .then(result => {
        // 刷新数据
        getOrder(this, wx.getStorageSync('userinfo').id);

        wx.showModal({
          title: '提示',
          content: result.data,
          success: function (res) {
            if (res.confirm) { //这里是点击了确定以后
              console.log('用户点击确定')
            } else { //这里是点击了取消以后
              console.log('用户点击取消')
            }
          }
        })
      })
  },
  // 去支付的方法
  goPay(d) {
    var id = d.target.dataset.info;
    wx.navigateTo({
      url: '/pages/cart2/cart2?id=' + id
    })
  }








})

// 获取我的订单信息
function getOrder(that, id) {
  request({
      url: "/orders/getByUserId?userid=" + id,
      data: {
        "id": id
      }
    })
    .then(result => {
      that.setData({
        orderList: result.data,
      })
    })
}