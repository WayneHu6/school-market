var util = require('../../common/common.js');
let URLINDEX=util.prefix();
Page({
  data:{
    // 搜索的数据
    src:{
      img1:URLINDEX+"/jmj/new_active/index/leftear.png",
      img2:URLINDEX+"/jmj/new_active/index/rightear.png",
      img3:URLINDEX+"/jmj/new_active/index/flower.png",
      img4:URLINDEX+"/jmj/new_active/index/search.png"
    },
    //顶部导航的数据
    navState:'',
    class1:"headItem",
    class2:"headItem active",
    headnav:[
      {
        name:'推荐',
        img:URLINDEX+"/jmj/icon/page1_bg1.png",
        url:'../prolist/prolist?id=0'
      },{
        name:'求购专区',
        img:URLINDEX+"/jmj/icon/page1_bg2.png",
        url:'../prolist/prolist?id=1'
      },{
        name:'帖子专区',
        img:URLINDEX+"/jmj/icon/page1_bg3.png",
        url:'../prolist/prolist?id=2'
      }
    ],
    prolist:{},
    // 最新品logo
    imgNew:URLINDEX+"/jmj/product/new.png",
    imgMore:URLINDEX+"/jmj/icon/more.png",
    imgHot:URLINDEX+"/jmj/product/hot.png",
    //随机品牌
    article_list1:{},
    imgLook:URLINDEX+"/jmj/icon/read.png",
    article_list2:{}
  },
  onLoad:function(options){
    var that=this;
    this.setData({
      navState:options.id
    })
  

  },
 //此为搜索相关的函数
    inputfocus:function(e){
      console.log(e);
      wx.navigateTo({
      url: "../search/search"
      })
    },
  //头部nav点击事件函数
  changeNavState: function(e) {
    var item=e.currentTarget.dataset.item;
    var key=e.currentTarget.dataset.key;
    console.log(key);
   
    wx.redirectTo({
      url: item.url
    });

  },
})