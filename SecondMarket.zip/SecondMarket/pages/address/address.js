// pages/address/address.js
import { request } from "../../request/request";


var util = require('../../common/common.js');
let URLINDEX=util.prefix();
Page({
  data:{
    img_edit:URLINDEX+"/jmj/icon/editaddr.png",
    img_del:URLINDEX+"/jmj/icon/del.png",
    img_default:URLINDEX+"/jmj/icon/choose.png",
    img_ci:URLINDEX+"/jmj/icon/circle.png",
    style1:"color:#f3026a",
    style2:"color:#bbb",
    showMessage:false
  },
  changeDefault:function(e){
     var that=this;
     var index=e.currentTarget.dataset.index;
    changedefault(that,index);
  },
  delAddr:function(e){
    var that=this;
    var index=e.currentTarget.dataset.index;
    deladdr(that,index);
  },
  editAddr:function(e){
    var that=this;
    var index=e.currentTarget.dataset.index;
    var store=that.data.addressList[index];
    //同步存储要编辑的地址
    wx.setStorageSync('addrList',store);
    wx.navigateTo({
      url: '../addaddr/addaddr?title=编辑收货地址'
    })
  },
  addAddr:function(){
    //同步存储要编辑的地址
    wx.setStorageSync('addrList',{});
    wx.navigateTo({
      url: '../addaddr/addaddr?title=添加收货地址'
    })
  },
  onLoad:function(options){
    var that=this;
    that.setData({
      from:options.from
    })
    this.getAddress(this,wx.getStorageSync('userinfo').id);
  },
  onShow:function(){
    var that=this;
    // getAddrList(that);
    this.getAddress(this,wx.getStorageSync('userinfo').id);

  },
     // 通过用户id获取收货地址
getAddress(that,userid) {
  request({url:"/address/getByUserId?userid="+userid,data:{"id":userid}})
  .then(result=>{
    that.setData({
      addressList:result.data,
    })
  })
 },
 // 选择地址
selectAddr(d) {
  console.log(d);
  var id = d.currentTarget.dataset.addr;
  this.setData({
    addr:id
  });
  wx.setStorageSync('addr', id)
  wx.navigateBack()
}





})

function getAddrList(that){
  wx.request({
    url: util.pre()+'/apic/address_list',
    data:{
      token:util.code()
    },
    header: {
      'Content-Type': 'application/json'
    },
    success: function(res) {
      that.setData({
        addr:res.data,
        showMessage:true
      })
    }
  })
}
function changedefault(that,index){
    var def=that.data.addr[index].is_default;
   var id=that.data.addr[index].id;
  wx.request({
    url: util.pre()+'/apic/address_default',
    data:{
      token:util.code(),
      id:id,
      is_default:1
    },
    header: {
      'Content-Type': 'application/json'
    },
    success: function(res) {
      that.data.addr.map(function(item){
        item.is_default=0;
      });
      that.data.addr[index].is_default=1;
      that.setData({
        addr:that.data.addr,
      });
      if(that.data.from=='cart2'){
        wx.navigateBack();
      }
    }
  })
}

// 删除地址
function deladdr(that,index){
  var id=that.data.addressList[index].id;
  wx.showModal({
    title: '刪除地址',
    content: '是否刪除該地址',
    success: function(res) {
      if (res.confirm) {
        // 发送删除请求
        request({url:"/address/delByid?id="+id,data:{"id":id}})
        .then(result=>{
          that.getAddress(that,wx.getStorageSync('userinfo').id);
        })


      }
    }
  })
}
 

