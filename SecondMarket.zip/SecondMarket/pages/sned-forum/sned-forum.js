// pages/bussback/bussback.js
const baseurl = "http://localhost:9088/";
import { request } from "../../request/request";

Page({

  /**
   * 页面的初始数据
   */
  data: {
    images:[],
    imagesStr:"",
    typeStr:"",
    statusStr:"",
    dealtypyStr:"",
    priceStr:"",
    telStr:"",
    nameStr:"",
    desStr:"",
    typeIndex:0,
    statusIndex:0,
    dealtypyIndex:0,
    sendtype:[
      '请选择发布类型',
      '校园日常',
      '表白',
      '失物招领',
      '防疫专栏',
      
    ],

    index: 0,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  toChooseImage(){
    var that = this;
    wx.chooseImage({
      count: 1, // 默认9
      sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: function (res) {
        // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片，只有一张图片获取下标为0
        var tempFilePaths = res.tempFilePaths[0];
        that.setData({
          imgUrl: tempFilePaths,
          actionSheetHidden: !that.data.actionSheetHidden
        });
        wx.uploadFile({
          filePath: tempFilePaths,
          name: 'file',
          dataType: "json",
          url: baseurl+'common/upload',
          success: function (res) {
            var datas = JSON.parse(res.data);
            if(datas.code==1){
              // 文件上传成功 更新ui
            var len = that.data.images.length;
            that.data.images[len] = baseurl+"common/download?name="+datas.data;
            that.setData({
              images: that.data.images
            })

            }



          },
          fail: function () {
            console.log(res);

            wx.showToast({
              title: '上传失败',
              icon: 'error',
              duration: 2000
            })
          }

        })

      }
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  listenerPickerSelected_type(d){
    var index = d.detail.value;
    this.setData({
      typeIndex: index,
      typeStr: this.data.sendtype[index]
    });
  },
  listenerPickerSelected_status(d){
    var index = d.detail.value;
    this.setData({
      statusIndex: index,
      statusStr: this.data.status[index]
    });
  },
  listenerPickerSelected_dealtypy(d){
    var index = d.detail.value;
    this.setData({
      dealtypyIndex: index,
      dealtypyStr: this.data.dealtypy[index]
    });
  },
  telBind(b){
    this.setData({
      telStr:b.detail.value
    });
  },
  nameBind(b){
    this.setData({
      nameStr:b.detail.value
    });
  },
  desBind(b){
    this.setData({
      desStr:b.detail.value
    });
  },
  priceBind(b){
    this.setData({
      priceStr:b.detail.value
    });
  },

  // 发布的方法
  sendGoods(){
    // 制作图片地址
    var array = this.data.images;
    for (let index = 0; index < array.length; index++) {
      const element = array[index];
      this.data.imagesStr += element + ",";
    }
    this.setData({
      imagesStr:this.data.imagesStr
    })

    var datas = this.data;
    request({url:"/forum/save",data:{
      "title":datas.nameStr,
      "content":datas.desStr,
      "type":datas.typeStr,
      "sendUser":wx.getStorageSync('userinfo').id,
      "imgs":datas.imagesStr,
      "icon":datas.images[0],

    }})
    .then(result=>{

      wx.showModal({
        title: '提示',
        content: result.data,
        success: function (res) {
          if (res.confirm) { //这里是点击了确定以后
            wx.navigateBack();
          } else { //这里是点击了取消以后
            wx.navigateBack();
          }
        }
      })


    })
  },
// 跳转到首页的界面
setDisabled(){
  wx.switchTab({
    url: '../../pages/index/index',
  })
},
})