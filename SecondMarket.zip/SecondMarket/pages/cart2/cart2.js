import { request } from "../../request/request";

var util = require('../../common/common.js');
let URLINDEX=util.prefix();
Page({
  data:{
    bg:URLINDEX+"/jmj/cart/line.png",
    img1:URLINDEX+"/jmj/cart/address.png",
    img2:URLINDEX+"/jmj/icon/add.png",
    img3:URLINDEX+"/jmj/cart/plane.png",
    checkState:true,
    imgcheck:URLINDEX+"/jmj/cart/red.png",
    imgcheckno:URLINDEX+"/jmj/cart/uncho.png",
    order:[],
    addressList:[]
  },
  checkS:function(){
    this.setData({
      checkState:!this.data.checkState
    })
  },
  onLoad:function(op){
    this.setData({
      id:op.id?op.id:null,
      num:op.num?op.num:null,
      type:op.type?op.type:null
    })
    this.getAddress(this,wx.getStorageSync('userinfo').id);
    this.getOrder(this,this.options.id);
  },
  onShow:function(){
    // var that=this;
    //   wx.request({
    //     url: util.pre()+'/apic/cart2',
    //     data: {
    //        token:util.code(), 
    //        id:that.data.id,
    //        num:that.data.num,
    //        type:that.data.type
    //     },
    //     success: function(res){
    //       var lastPay=(parseFloat(res.data.data.sum)+parseFloat(res.data.data.delivery_money)).toFixed(2);
    //       that.setData({
    //         order:res.data.data,
    //         lastPay:lastPay
    //       })
    //     }
    //   });
  },

// 通过订单id就获取订单信息
getOrder(that,id) {
  request({url:"/orders/getById?id="+id,data:{"id":id}})
  .then(result=>{
    that.setData({
      order:result.data,
    })
  })
 },
 // 通过用户id获取收货地址
getAddress(that,userid) {
  request({url:"/address/getByUserId?userid="+userid,data:{"id":userid}})
  .then(result=>{
    that.setData({
      addressList:result.data,
    })
  })
 },
 // 支付订单
 payOrder(){
  request({url:"/orders/pay",data:{
    "id":this.data.order.id,
    "addressid":wx.getStorageSync('addr'),
  }})
  .then(result=>{
    wx.showModal({
      title: '提示',
      content: result.data,
      success: function (res) {
        if (res.confirm) { //这里是点击了确定以后
          console.log('用户点击确定')
          wx.redirectTo({
            url: '/pages/order/order?cid=0&title=全部订单',
          })
        } else { //这里是点击了取消以后
          console.log('用户点击取消')
          wx.redirectTo({
            url: '/pages/order/order?cid=0&title=全部订单',
          })
        }
      }
    })

  })
 },


})