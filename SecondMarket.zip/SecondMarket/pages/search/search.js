// pages/search/search.js
import { request } from "../../request/request";


var util = require('../../common/common.js');
let URLINDEX=util.prefix();
Page({
  data:{
    // historyList:['专业书籍'],
    // hotList:['夏凉被子','英语教材','加厚大衣','考公教材','床上床桌'],
    src:{
      img1:URLINDEX+"/jmj/new_active/index/leftear.png",
      img2:URLINDEX+"/jmj/new_active/index/rightear.png",
      img3:URLINDEX+"/jmj/new_active/index/flower.png",
      img4:URLINDEX+"/jmj/new_active/index/search.png"
    },
    placeholder:"请输入搜索关键词",
    inputValue:"",
    word:[
    "<image src='../../images/8.png'></image>",
    "<image src='https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fwww.gpbctv.com%2Fuploads%2F20210424%2Fzip_1619246266UkP6CL.jpg&refer=http%3A%2F%2Fwww.gpbctv.com&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=auto?sec=1668140354&t=85ae1db3882cd5c7bead473fcf84209e'></image>",
    "<image src='../../images/8.png'></image>",
    "<image src='../../images/8.png'></image>",
    ],
    products:[],
  },
  search(){
    wx.showToast({
        icon:'none',
        title: '阿欧，搜索不到哦',
    })
    
},
  // 表单事件
  formSubmit:function(e){
     wx.redirectTo({
      url: "../searchlist/searchlist?word="+this.data.inputValue+"&state=1"
    })
  },
  inputfocus:function(e){
  },
  inputblur:function(e){
  },
  bindInput:function(e){
    this.setData({
        inputValue:e.detail.value
      })
  },
  searchCancle:function(e){
    wx.navigateBack()
  },
  onLoad:function(options){
    var that=this;
    if(!wx.getStorageSync('searchData')){
      getSearchWords(that)
    }else{
      var getSearch = wx.getStorageSync('searchData');
      this.setData({
        // word:getSearch,
        inputValue:''
      })
    }
  },
 







})
// 获取专辑的函数
function getSearchWords(that){
    wx.request({
      url: 'http://m.jiumaojia.com/apic/search_words',
      header:{
          'Content-Type': 'application/json'
      },
      success: function(res) {
          wx.setStorageSync('searchData',res.data);
          that.setData({
          word:that.data.word.concat(res.data),
      })
      }
    }) 
}