// pages/login/login.js
import { request } from "../../request/request";


Page({

  /**
   * 页面的初始数据
   */
  data: {
    username:"mwy",
    password:"123456",
    open: false,//默认不显示密码
    focus:false,//是否获取焦点
  },
  switch() {
    this.setData({
      open: !this.data.open
    })
  },
  focus(){
    this.setData({
      focus:true
    })
  },
  blur(){
    this.setData({
      focus:false
    })
  },
  

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

username(b){
  this.setData({
    username:b.detail.value
  });
},
password(b){
  this.setData({
    password:b.detail.value
  });
},
// 用户登录的方法
login(){
  request({url:"user/login",data:{"account":this.data.username,"password":this.data.password}})
  .then(result=>{
    if(result.code==1){
      // 登录成功 保存用户信息 跳转到首页
      wx.setStorageSync('userinfo', result.data);
      wx.reLaunch({
        url: '../index/index'
      })
    }else{
      // 登录失败 弹出提示窗
      wx.showModal({
        title: '失败',
        content: result.msg,
        success: function (res) {
          if (res.confirm) { //这里是点击了确定以后
            console.log('用户点击确定')
          } else { //这里是点击了取消以后
            console.log('用户点击取消')
          }
        }
      })


    }

  })
},






})