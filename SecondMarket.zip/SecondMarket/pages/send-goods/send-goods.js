// pages/bussback/bussback.js
const baseurl = "http://localhost:9088/";
import { request } from "../../request/request";

Page({

  /**
   * 页面的初始数据
   */
  data: {
    images:[],
    imagesStr:"",
    typeStr:"",
    statusStr:"",
    dealtypyStr:"",
    priceStr:"",
    telStr:"",
    nameStr:"",
    desStr:"",
    typeIndex:0,
    statusIndex:0,
    dealtypyIndex:0,
    sendtype:[
      '请选择发布类型',
      '求购信息',
      '二手甩卖',
      
    ],
    status:[
      '请选择成色',
      '全新',
      '99新',
      '半新',
      '旧',
      
    ],
    dealtypy:[
      '请选择交易方式',
      '平台送货上门',
      '线下见面交易',
      '卖家送货上门',
      '买家上门自提',
      '互换',
    ],
    index: 0,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  toChooseImage(){
    var that = this;
    wx.chooseImage({
      count: 1, // 默认9
      sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: function (res) {
        // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片，只有一张图片获取下标为0
        var tempFilePaths = res.tempFilePaths[0];
        that.setData({
          imgUrl: tempFilePaths,
          actionSheetHidden: !that.data.actionSheetHidden
        });
        wx.uploadFile({
          filePath: tempFilePaths,
          name: 'file',
          dataType: "json",
          url: baseurl+'common/upload',
          success: function (res) {
            var datas = JSON.parse(res.data);
            if(datas.code==1){
              // 文件上传成功 更新ui
            var len = that.data.images.length;
            that.data.images[len] = baseurl+"common/download?name="+datas.data;
            that.setData({
              images: that.data.images
            })

            }



          },
          fail: function () {
            console.log(res);

            wx.showToast({
              title: '上传失败',
              icon: 'error',
              duration: 2000
            })
          }

        })

      }
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  listenerPickerSelected_type(d){
    var index = d.detail.value;
    this.setData({
      typeIndex: index,
      typeStr: this.data.sendtype[index]
    });
  },
  listenerPickerSelected_status(d){
    var index = d.detail.value;
    this.setData({
      statusIndex: index,
      statusStr: this.data.status[index]
    });
  },
  listenerPickerSelected_dealtypy(d){
    var index = d.detail.value;
    this.setData({
      dealtypyIndex: index,
      dealtypyStr: this.data.dealtypy[index]
    });
  },
  telBind(b){
    this.setData({
      telStr:b.detail.value
    });
  },
  nameBind(b){
    this.setData({
      nameStr:b.detail.value
    });
  },
  desBind(b){
    this.setData({
      desStr:b.detail.value
    });
  },
  priceBind(b){
    this.setData({
      priceStr:b.detail.value
    });
  },

  // 发布商品/求购信息的方法
  sendGoods(){
    // 制作图片地址
    var array = this.data.images;
    for (let index = 0; index < array.length; index++) {
      const element = array[index];
      this.data.imagesStr += element + ",";
    }
    this.setData({
      imagesStr:this.data.imagesStr
    })

    var datas = this.data;
    request({url:"/goods/save",data:{
      "name":datas.nameStr,
      "type":datas.typeStr,
      "price":datas.priceStr,
      "status":datas.statusStr,
      "dealtypy":datas.dealtypyStr,
      "sendUser":wx.getStorageSync('userinfo').id,
      "contactWay":datas.telStr,
      "imgs":datas.imagesStr,
      "describes":datas.desStr,
      "icon":datas.images[0],

    }})
    .then(result=>{
      console.log("code----"+result.code);
      if(result.code==1){
        var that = this;
        wx.showModal({
          title: '提示',
          content: '发布成功',
          success: function (res) {
            if (res.confirm) { //这里是点击了确定以后
              console.log('用户点击确定')
              // that.setData({
              //           typeStr:"",
              //           telStr:"",
              //           nameStr:"",
              //           desStr:"",
              //           priceStr:"",
              //           statusStr:"",
              //           dealtypyStr:"",
              //           imagesStr:"",
              //         });
            } else { //这里是点击了取消以后
              console.log('用户点击取消')
            }
          }
        })



        // wx.showModal({
        //   title: '提示',
        //   content: result.msg,
        //   success: function (res) {
        //     if (res.confirm) { //这里是点击了确定以后
        //       console.log('用户点击确定')
        //       this.setData({
        //         typeStr:"",
        //         telStr:"",
        //         nameStr:"",
        //         desStr:"",
        //         priceStr:"",
        //         statusStr:"",
        //         dealtypyStr:"",
        //         imagesStr:"",
        //       });
        //     } else { //这里是点击了取消以后
        //       console.log('用户点击取消')
        //       this.setData({
        //         typeStr:"",
        //         telStr:"",
        //         nameStr:"",
        //         desStr:"",
        //         priceStr:"",
        //         statusStr:"",
        //         dealtypyStr:"",
        //         imagesStr:"",
        //       });
        //     }
        //   }
        // })
      }else{
        wx.showModal({
          title: '提示',
          content: "提交失败"
        })


      }




    })
  },

})