// pages/editPersion/editPersion.js
import { request } from "../../request/request";


Page({

  /**
   * 页面的初始数据
   */
  data: {
    account: "加载中...",
    nickname: "加载中...",
    sex: "加载中...",
    college: "加载中...",
    grade: "加载中...",
    roomnumb: "加载中...",
    tel: "加载中...",
    idcard: "加载中...",
    id:"",
  },
  account(e) {
    this.setData({
      account: e.detail.value
    })
  },
  nickname(e) {
    this.setData({
      nickname: e.detail.value
    })
  },
  sex(e) {
    this.setData({
      sex: e.detail.value
    })
  },
  college(e) {
    this.setData({
      college: e.detail.value
    })
  },
  grade(e) {
    this.setData({
      grade: e.detail.value
    })
  },
  roomnumb(e) {
    this.setData({
      roomnumb: e.detail.value
    })
  },
  tel(e) {
    this.setData({
      tel: e.detail.value
    })
  },
  idcard(e) {
    this.setData({
      idcard: e.detail.value
    })
  },

  onConfirmChange() {
    request({
      url: "/user/update",
      data: {
        "id":wx.getStorageSync('userinfo').id,
        "account": this.data.account,
        "college": this.data.college,
        "grade": this.data.grade,
        "idcard": this.data.idcard,
        "nickname": this.data.nickname,
        "roomnumb": this.data.roomnumb,
        "sex": this.data.sex,
        "tel": this.data.tel,
      }
    })
    .then(result => {
      wx.showToast({
        title: result.data
      });
      this.getPerson();

    })


  },

  getPerson() {
    request({
      url: "/user/getById?id=" + wx.getStorageSync('userinfo').id,
      data: {
        "id": "1"
      }
    })
    .then(result => {
      this.setData({
        userinfo: result.data,
        account: result.data.account,
        college: result.data.college,
        grade: result.data.grade,
        idcard: result.data.idcard,
        nickname: result.data.nickname,
        roomnumb: result.data.roomnumb,
        sex: result.data.sex,
        tel: result.data.tel,

      });

       // 重设用户信息
       wx.setStorageSync('userinfo', result.data)
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getPerson();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.getPerson();

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})