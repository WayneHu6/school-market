package cn.only.hw.secondmarketserver.controller;

import cn.only.hw.secondmarketserver.entity.Catechild;
import cn.only.hw.secondmarketserver.entity.Category;
import cn.only.hw.secondmarketserver.entity.Categorys;
import cn.only.hw.secondmarketserver.entity.Notice;
import cn.only.hw.secondmarketserver.service.CatechildService;
import cn.only.hw.secondmarketserver.service.CategoryService;
import cn.only.hw.secondmarketserver.util.Result;
import com.alibaba.fastjson.JSONArray;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import io.swagger.annotations.Api;

import java.util.List;


/**
 * (Category)表控制层
 *
 * @author 户伟伟
 * @since 2022-10-02 03:03:22
 */
@RestController
@RequestMapping("/category")
@Slf4j
@Api(tags = "分类相关操作")
public class CategoryController {
    /**
     * 服务对象
     */
    @Autowired
    private CategoryService categoryService;
    @Autowired
    private CatechildService catechildService;


    @ApiOperation("获取分类栏目的方法")
    @PostMapping("/list")
    public Result<JSONArray> login() {
        log.info("获取公告菜单:");
        List<Category> categories = categoryService.list();
        if (categories.size() > 0) {
            JSONArray jsonArray = new JSONArray();
            for (int i = 0; i < categories.size(); i++) {
                List<Catechild> catechilds = catechildService.getByCateId(String.valueOf(categories.get(i).getCateid()));

                Categorys categorys = new Categorys();
                categorys.setCateid(categories.get(i).getCateid());
                categorys.setCatename(categories.get(i).getCatename());
                categorys.setIshavechild(categories.get(i).getIshavechild());

                categorys.setChildren(catechilds);

                jsonArray.add(categorys);

            }

            return Result.success(jsonArray);

        } else {
            return Result.error("暂时没有数据");
        }
    }

}

