package cn.only.hw.secondmarketserver.service.impl;

import cn.only.hw.secondmarketserver.entity.Address;
import cn.only.hw.secondmarketserver.dao.AddressDao;
import cn.only.hw.secondmarketserver.service.AddressService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;


/**
 * (Address)表服务实现类
 *
 * @author 户伟伟
 * @since 2022-10-06 18:01:52
 */
@Service
public class AddressServiceImpl extends ServiceImpl<AddressDao,Address> implements AddressService {
 
}
