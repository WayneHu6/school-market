package cn.only.hw.secondmarketserver.entity;

import lombok.Data;

/**
 * 作者          : 户伟伟
 * 创建日期       : Created in 2022/10/3 17:43
 * 描述          : TODO
 * 类名          : EditPojo
 */

@Data
public class EditPojo {
    private String field;
    private String val;
    private String id;
}
