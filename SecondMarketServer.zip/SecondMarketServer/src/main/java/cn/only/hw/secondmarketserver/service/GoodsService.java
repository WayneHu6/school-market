package cn.only.hw.secondmarketserver.service;

import cn.only.hw.secondmarketserver.entity.Goods;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * (Goods)表服务接口
 *
 * @author 户伟伟
 * @since 2022-10-03 16:23:00
 */
public interface GoodsService extends IService<Goods>{

    List<Goods> getByType(String type);
}
