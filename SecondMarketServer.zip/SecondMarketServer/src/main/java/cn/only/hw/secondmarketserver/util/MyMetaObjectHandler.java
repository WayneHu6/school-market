package cn.only.hw.secondmarketserver.util;

import com.baomidou.mybatisplus.core.handlers.MetaObjectHandler;
import lombok.extern.log4j.Log4j2;
import org.apache.ibatis.reflection.MetaObject;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.Date;

/**
 * 作者          ：户伟伟
 * 创建日期       ：Created in 2022/9/19 10:38
 * 描述          ：元数据处理器
 * 类名          ：MyMetaObjectHandler
 */

@Component
@Log4j2
public class MyMetaObjectHandler implements MetaObjectHandler {
    @Override
    public void insertFill(MetaObject metaObject) {
        // 插入数据时执行
        log.info("公共字段自动填充[insert]...");
        log.info(metaObject.toString());
        metaObject.setValue("sendTime", new Date());
        metaObject.setValue("updateTime", new Date());
//        metaObject.setValue("createUser", BaseContext.getCurrentId());
//        metaObject.setValue("updateUser", BaseContext.getCurrentId());



    }

    @Override
    public void updateFill(MetaObject metaObject) {
        // 更新数据时执行
        log.info("公共字段自动填充[update]...");
        log.info(metaObject.toString());
        metaObject.setValue("updateTime", new Date());
//        metaObject.setValue("updateUser", BaseContext.getCurrentId());

    }


}
