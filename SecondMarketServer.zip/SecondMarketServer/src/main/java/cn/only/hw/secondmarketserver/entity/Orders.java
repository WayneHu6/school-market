package cn.only.hw.secondmarketserver.entity;

import java.util.Date;
import java.io.Serializable;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * (Orders)实体类
 *
 * @author 户伟伟
 * @since 2022-10-08 11:22:44
 */
@ApiModel("Orders")
public class Orders implements Serializable {
    private static final long serialVersionUID = -78662925882250114L;
    
        
    private Integer id;
    /**
     * 下单的用户id
     */
    @ApiModelProperty("下单的用户id")    
    private Integer userid;
    /**
     * 下单的商品id
     */
    @ApiModelProperty("下单的商品id")    
    private Integer goodsid;
    /**
     * 提交时间
     */
    @ApiModelProperty("提交时间")
    @TableField(fill = FieldFill.INSERT)
    private Date sendTime;
    /**
     * 订单价格
     */
    @ApiModelProperty("订单价格")    
    private Double price;
    /**
     * 订单状态(1下单待付款 2付款待发货 3发货待收货 4已收货完成 5取消订单 )
     */
    @ApiModelProperty("订单状态(1下单待付款 2付款待发货 3发货待收货 4已收货完成 5取消订单 )")    
    private String state;
    /**
     * 订单信息更新时间
     */
    @ApiModelProperty("订单信息更新时间")
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private Date updateTime;
    /**
     * 送货地址id
     */
    @ApiModelProperty("送货地址id")    
    private Integer addressid;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUserid() {
        return userid;
    }

    public void setUserid(Integer userid) {
        this.userid = userid;
    }

    public Integer getGoodsid() {
        return goodsid;
    }

    public void setGoodsid(Integer goodsid) {
        this.goodsid = goodsid;
    }

    public Date getSendTime() {
        return sendTime;
    }

    public void setSendTime(Date sendTime) {
        this.sendTime = sendTime;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getAddressid() {
        return addressid;
    }

    public void setAddressid(Integer addressid) {
        this.addressid = addressid;
    }

}

