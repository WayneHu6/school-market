package cn.only.hw.secondmarketserver.service;

import cn.only.hw.secondmarketserver.entity.Manager;
import cn.only.hw.secondmarketserver.entity.User;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * (Manager)表服务接口
 *
 * @author 户伟伟
 * @since 2022-10-03 16:43:47
 */
public interface ManagerService extends IService<Manager>{

    Manager login(Manager manager);
}
