package cn.only.hw.secondmarketserver.dao;

import cn.only.hw.secondmarketserver.entity.Catechild;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * (Catechild)表数据库访问层
 *
 * @author 户伟伟
 * @since 2022-10-02 03:03:35
 */
 @Mapper
public interface CatechildDao extends BaseMapper<Catechild> {

}

