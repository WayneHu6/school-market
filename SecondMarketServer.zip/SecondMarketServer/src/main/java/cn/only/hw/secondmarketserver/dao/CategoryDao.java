package cn.only.hw.secondmarketserver.dao;

import cn.only.hw.secondmarketserver.entity.Category;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * (Category)表数据库访问层
 *
 * @author 户伟伟
 * @since 2022-10-02 03:03:22
 */
 @Mapper
public interface CategoryDao extends BaseMapper<Category> {

}

