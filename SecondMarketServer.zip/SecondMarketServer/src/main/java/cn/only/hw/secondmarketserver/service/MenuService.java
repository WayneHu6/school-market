package cn.only.hw.secondmarketserver.service;

import cn.only.hw.secondmarketserver.entity.Menu;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * (Menu)表服务接口
 *
 * @author 户伟伟
 * @since 2022-10-02 02:03:04
 */
public interface MenuService extends IService<Menu>{

}
