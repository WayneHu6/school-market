package cn.only.hw.secondmarketserver.controller;

import cn.only.hw.secondmarketserver.util.Result;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.UUID;

/**
 * 作者          ：户伟伟
 * 创建日期       ：Created in 2022/9/19 16:30
 * 描述          ：TODO 通用的controller
 * 类名          ：CommonController
 */

@RestController
@RequestMapping("/common")
@Slf4j
public class CommonController {
    @Value("${common.path}")
    private String basePath;

    @PostMapping("/upload")
    public Result<String> upload(MultipartFile file){
        /**
         * 作者：户伟伟
         * description: TODO 文件上传
         * create time: 2022/9/19 16:37
         *  * @Param: file
         * @return com.itheima.reggie.util.Result<java.lang.String>
         */


        // 获取原始的文件名
        String name = file.getOriginalFilename();

        // 使用uuid生成文件名 防止文件名重复覆盖文件
        String nameUUID = UUID.randomUUID().toString();
        // 截取文件后缀
        String suffix = file.getOriginalFilename().substring(file.getOriginalFilename().lastIndexOf("."));

        // 判断目录是否存在
        File dir = new File(basePath);
        if (!dir.exists()){
            // 不存在 先创建
            dir.mkdirs();
        }

        try {
            // 移动文件到指定位置
            file.transferTo(new File(basePath+nameUUID+suffix));
        } catch (IOException e) {
            e.printStackTrace();
        }
        log.info(file.toString());
        return Result.success(nameUUID+suffix);
    }


    @GetMapping("/download")
    public void download(String name, HttpServletResponse response){
        /**
         * 作者：户伟伟
         * description: TODO 文件下载
         * create time: 2022/9/19 17:07
         *  * @Param: name
         * @Param: response
         * @return void
         */

        // 输入流 通过输入流读取文件
        try {
            FileInputStream fileInputStream = new FileInputStream(new File(basePath + name));
            // 通过输出流对象 将文件写回浏览器
            ServletOutputStream outputStream = response.getOutputStream();
            // 设置返回类型
            response.setContentType("image/jpeg");
            int len = 0;
            byte[] bytes = new byte[1024];
            while ((len = fileInputStream.read(bytes)) != -1){
                outputStream.write(bytes,0,len);
                outputStream.flush();
            }
            // 关闭资源
            outputStream.close();
            fileInputStream.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }


}
