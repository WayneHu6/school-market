package cn.only.hw.secondmarketserver.controller;

import cn.only.hw.secondmarketserver.entity.User;
import cn.only.hw.secondmarketserver.service.UserService;
import cn.only.hw.secondmarketserver.util.Result;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import io.swagger.annotations.Api;

import javax.servlet.http.HttpSession;


/**
 * (User)表控制层
 *
 * @author 户伟伟
 * @since 2022-10-03 13:21:23
 */
@RestController
@RequestMapping("/user")
@Slf4j
@Api(tags = "用户相关操作")
public class UserController {
    /**
     * 服务对象
     */
    @Autowired
    private UserService userService;

    @ApiOperation("用户登录的方法")
    @ApiImplicitParam(name = "user", value = "以后登录信息", required = true)
    @PostMapping("/login")
    public Result<User> login(@RequestBody User user, HttpSession session) {
        log.info("登录:{}",user);
        User loginUser = userService.login(user);
        if (loginUser != null) {
            // 保存用户登录信息
            session.setAttribute("user", loginUser.getId());
            return Result.success(loginUser);
        }
        return Result.error("登录失败");
    }

    @ApiOperation("用户注册的方法")
    @ApiImplicitParam(name = "user", value = "注册的用户信息", required = true)
    @PostMapping("/register")
    public Result<String> register(@RequestBody User user) {
        log.info("注册:{}",user);
        user.setIcon("https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fc-ssl.duitang.com%2Fuploads%2Fblog%2F202107%2F09%2F20210709142454_dc8dc.thumb.1000_0.jpeg&refer=http%3A%2F%2Fc-ssl.duitang.com&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=auto?sec=1667366231&t=f3680fb12f892a66c704ee8f6ab444ae");
        user.setNickname("某人");
        return userService.register(user);
    }

    @ApiOperation("用户完善个人信息的方法")
    @ApiImplicitParam(name = "user", value = "要完善的用户信息", required = true)
    @PostMapping("/update")
    public Result<String> update(@RequestBody User user) {
        log.info("完善信息:{}",user);
        userService.updateById(user);
        return Result.success("更新成功");
    }

    @ApiOperation("通过用户id获取用户信息的方法")
    @PostMapping("/getById")
    public Result<User> getById(Integer id) {
        log.info("通过id获取用户:{}",id);
        User user = userService.getById(id);
        return Result.success(user);
    }




}

