package cn.only.hw.secondmarketserver.service;

import cn.only.hw.secondmarketserver.entity.Cart;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * (Cart)表服务接口
 *
 * @author 户伟伟
 * @since 2022-10-06 11:15:35
 */
public interface CartService extends IService<Cart>{

}
