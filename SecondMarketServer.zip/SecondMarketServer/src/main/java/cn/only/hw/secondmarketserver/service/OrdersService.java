package cn.only.hw.secondmarketserver.service;

import cn.only.hw.secondmarketserver.entity.Orders;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * (Orders)表服务接口
 *
 * @author 户伟伟
 * @since 2022-10-08 11:22:44
 */
public interface OrdersService extends IService<Orders>{

}
