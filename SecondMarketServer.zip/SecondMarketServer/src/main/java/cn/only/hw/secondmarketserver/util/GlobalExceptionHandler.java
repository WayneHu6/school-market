package cn.only.hw.secondmarketserver.util;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.sql.SQLIntegrityConstraintViolationException;

/**
 * 作者          ：户伟伟
 * 创建日期       ：Created in 2022/8/30 14:23
 * 描述          ：TODO 全局异常捕获处理
 * 类名          ：GlobalExceptionHandler
 */

// 拦截加了RestController注解的类
@ControllerAdvice(annotations = {RestController.class, Controller.class})
@ResponseBody
@Slf4j
public class GlobalExceptionHandler {

    @ExceptionHandler(SQLIntegrityConstraintViolationException.class)
    public Result<String> exceptionHandler(SQLIntegrityConstraintViolationException ex){
        log.error(ex.getMessage());
        if (ex.getMessage().contains("Duplicate entry")){
            String[] split = ex.getMessage().split(" ");
            String msg = "账号" + split[2] + "已存在";
            return Result.error(msg);
        }
        return Result.error("操作失败了-未知错误");
    }

    @ExceptionHandler(CustomException.class)
    public Result<String> exceptionHandler(CustomException ex){
        /**
         * 作者：户伟伟
         * description: TODO 处理自定义异常
         * create time: 2022/9/19 12:53
         *  * @Param: ex
         * @return com.itheima.reggie.util.Result<java.lang.String>
         */
        log.error(ex.getMessage());
        return Result.error("操作失败了-"+ex.getMessage());
    }


}
