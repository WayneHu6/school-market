package cn.only.hw.secondmarketserver.controller;

import cn.only.hw.secondmarketserver.dto.CartGoodsDto;
import cn.only.hw.secondmarketserver.entity.Cart;
import cn.only.hw.secondmarketserver.entity.Cart;
import cn.only.hw.secondmarketserver.entity.Goods;
import cn.only.hw.secondmarketserver.service.CartService;
import cn.only.hw.secondmarketserver.service.GoodsService;
import cn.only.hw.secondmarketserver.util.Result;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import io.swagger.annotations.Api;

import java.util.List;
import java.util.stream.Collectors;


/**
 * (Cart)表控制层
 *
 * @author 户伟伟
 * @since 2022-10-06 11:15:35
 */
@RestController
@RequestMapping("/cart")
@Slf4j
@Api(tags = "Cart")
public class CartController {
    /**
     * 服务对象
     */
    @Autowired
    private CartService cartService;
    @Autowired
    private GoodsService goodsService;


    @ApiOperation("获取所有购物车的方法")
    @PostMapping("/list")
    public Result<List<Cart>> login() {
        log.info("获取所有7购物车:");
        List<Cart> list = cartService.list();
        if (list.size() > 0) {
            return Result.success(list);
        }
        return Result.error("暂时没有数据");
    }


    @ApiOperation("通过id获取购物车的方法")
    @PostMapping("/getById")
    public Result<Cart> getById(Integer id) {
        log.info("获取所有购物车:");
        Cart cart = cartService.getById(id);
        if (cart != null) {

            return Result.success(cart);
        }
        return Result.error("暂时没有数据");
    }



    @ApiOperation("按用户id获取购物车的方法")
    @PostMapping("/getByUserId")
    public Result<List<CartGoodsDto>> getByUserId(String userid) {
        log.info("按用户id获取购物车:{}",userid);
        LambdaQueryWrapper<Cart> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(Cart::getUserid,userid);
        List<Cart> cartList = cartService.list(queryWrapper);
        // 获取商品信息进行封装
        if (cartList.size() > 0) {
            List<CartGoodsDto> list = cartList.stream().map(item -> {
                Goods goods = goodsService.getById(item.getGoodsid());
                CartGoodsDto cartGoodsDto = new CartGoodsDto();
                BeanUtils.copyProperties(item,cartGoodsDto); // 对象拷贝
                cartGoodsDto.setGoods(goods);
                return cartGoodsDto;
            }).collect(Collectors.toList());
            return Result.success(list);
        }
        return Result.error("暂时没有数据");
    }

    @ApiOperation("加入购物车的方法")
    @PostMapping("/save")
    public Result<String> save(@RequestBody Cart cart) {
        log.info("加入购物车:{}",cart);

        boolean isSave = cartService.save(cart);
        if (isSave) {
            return Result.success("加入购物车成功");
        }
        return Result.error("加入购物车失败");
    }


    @ApiOperation("删除购物车物品的方法")
    @PostMapping("/del")
    public Result<String> del(String id) {
        log.info("删除购物车物品:{}",id);

        boolean isSave = cartService.removeById(id);
        if (isSave) {
            return Result.success("删除成功");
        }
        return Result.error("删除失败");
    }

}

