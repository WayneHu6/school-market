package cn.only.hw.secondmarketserver.dao;

import cn.only.hw.secondmarketserver.entity.Manager;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * (Manager)表数据库访问层
 *
 * @author 户伟伟
 * @since 2022-10-03 16:43:47
 */
 @Mapper
public interface ManagerDao extends BaseMapper<Manager> {

}

