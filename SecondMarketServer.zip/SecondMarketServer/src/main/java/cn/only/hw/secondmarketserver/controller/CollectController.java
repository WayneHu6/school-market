package cn.only.hw.secondmarketserver.controller;

import cn.only.hw.secondmarketserver.dto.CollectGoodsDto;
import cn.only.hw.secondmarketserver.entity.Collect;
import cn.only.hw.secondmarketserver.entity.Collect;
import cn.only.hw.secondmarketserver.entity.Goods;
import cn.only.hw.secondmarketserver.service.CollectService;
import cn.only.hw.secondmarketserver.service.GoodsService;
import cn.only.hw.secondmarketserver.util.Result;
import com.alibaba.fastjson.JSONArray;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import io.swagger.annotations.Api;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;


/**
 * (Collect)表控制层
 *
 * @author 户伟伟
 * @since 2022-10-08 18:40:24
 */
@RestController
@RequestMapping("/collect")
@Slf4j
@Api(tags = "Collect")
public class CollectController {
    /**
     * 服务对象
     */
    @Autowired
    private CollectService collectService;
    @Autowired
    private GoodsService goodsService;


    @ApiOperation("获取所有收藏的方法")
    @PostMapping("/list")
    public Result<List<Collect>> login() {
        log.info("获取所有收藏:");
        List<Collect> list = collectService.list();
        if (list.size() > 0) {
            return Result.success(list);
        }
        return Result.error("暂时没有数据");
    }


    @ApiOperation("通过id获取收藏的方法")
    @PostMapping("/getById")
    public Result<Collect> getById(Integer id) {
        log.info("获取所有收藏:");
        Collect collect = collectService.getById(id);
        if (collect != null) {
            return Result.success(collect);
        }
        return Result.error("暂时没有数据");
    }

    @ApiOperation("检查是否已收藏的方法")
    @PostMapping("/check")
    public Result<List<Collect>> check(Integer type,Integer sid) {
        log.info("检查是否收藏:{},{}",type,sid);
        LambdaQueryWrapper<Collect> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(Collect::getType,type);
        queryWrapper.eq(Collect::getSid,sid);
        List<Collect> list = collectService.list(queryWrapper);
        if (list.size()>0) {
            return Result.success(list);
        }
        return Result.error("暂时没有数据");
    }

    @ApiOperation("通过用户id获取收藏的方法")
    @PostMapping("/getByUserId")
    public Result<List<CollectGoodsDto>> getByUserId(Integer userid) {
        log.info("获取收藏:{}",userid);
        LambdaQueryWrapper<Collect> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(Collect::getUserid,userid);
        List<Collect> collectList = collectService.list(queryWrapper);
        List<CollectGoodsDto> list = collectList.stream().map(item -> {
            Goods goods = goodsService.getById(item.getSid());
            CollectGoodsDto collectGoodsDto = new CollectGoodsDto();
            collectGoodsDto.setGoods(goods);
            BeanUtils.copyProperties(item, collectGoodsDto);
            return collectGoodsDto;
        }).collect(Collectors.toList());

        if (list.size()>0) {
            return Result.success(list);
        }
        return Result.error("暂时没有数据");
    }



    @ApiOperation("删除收藏的方法")
    @PostMapping("/del")
    public Result<String> del(String id) {
        log.info("删除收藏:{}",id);
        boolean b = collectService.removeById(id);
        if (b) {
            return Result.success("删除成功");
        }
        return Result.error("删除失败");
    }

    @ApiOperation("发布收藏的方法")
    @PostMapping("/save")
    public Result<String> save(@RequestBody Collect collect) {
        log.info("发布收藏:{}",collect);
        boolean isSave = collectService.save(collect);
        if (isSave) {
            return Result.success("收藏成功");
        }
        return Result.error("收藏失败");
    }



}

