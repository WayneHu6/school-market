package cn.only.hw.secondmarketserver.entity;

import java.io.Serializable;

import com.baomidou.mybatisplus.annotation.TableId;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * (Catechild)实体类
 *
 * @author 户伟伟
 * @since 2022-10-03 23:47:22
 */
@ApiModel("Catechild")
public class Catechild implements Serializable {
    private static final long serialVersionUID = 853544861278497715L;

    @TableId
    private Integer childid;
    
        
    private Integer cateid;
    
        
    private String goodid;
    
        
    private String image;
    
        
    private String childname;


    public Integer getChildid() {
        return childid;
    }

    public void setChildid(Integer childid) {
        this.childid = childid;
    }

    public Integer getCateid() {
        return cateid;
    }

    public void setCateid(Integer cateid) {
        this.cateid = cateid;
    }

    public String getGoodid() {
        return goodid;
    }

    public void setGoodid(String goodid) {
        this.goodid = goodid;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getChildname() {
        return childname;
    }

    public void setChildname(String childname) {
        this.childname = childname;
    }

}

