package cn.only.hw.secondmarketserver.entity;

import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * (Manager)实体类
 *
 * @author 户伟伟
 * @since 2022-10-03 16:43:47
 */
@ApiModel("Manager")
public class Manager implements Serializable {
    private static final long serialVersionUID = -59889277545640309L;
    
        
    private Integer id;
    
        
    private String account;
    
        
    private String password;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

}

