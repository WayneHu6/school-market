package cn.only.hw.secondmarketserver.controller;

import cn.only.hw.secondmarketserver.dto.OrderGoodsDto;
import cn.only.hw.secondmarketserver.dto.OrdersDto;
import cn.only.hw.secondmarketserver.entity.Goods;
import cn.only.hw.secondmarketserver.entity.Orders;
import cn.only.hw.secondmarketserver.service.AddressService;
import cn.only.hw.secondmarketserver.service.GoodsService;
import cn.only.hw.secondmarketserver.service.OrdersService;
import cn.only.hw.secondmarketserver.service.UserService;
import cn.only.hw.secondmarketserver.util.Result;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import io.swagger.annotations.Api;

import java.util.List;
import java.util.stream.Collectors;


/**
 * (Orders)表控制层
 *
 * @author 户伟伟
 * @since 2022-10-08 11:22:44
 */
@RestController
@RequestMapping("/orders")
@Slf4j
@Api(tags = "Orders")
public class OrdersController {
    /**
     * 服务对象
     */
    @Autowired
    private OrdersService ordersService;

    @Autowired
    private GoodsService goodsService;

    @Autowired
    private UserService userService;

    @Autowired
    private AddressService addressService;



    @ApiOperation("获取所有订单的方法")
    @PostMapping("/getAllOrder")
    public Result login() {
        log.info("获取所有订单:");
        List<Orders> list = ordersService.list();

        if (list.size() > 0) {
            List<OrdersDto> collect = list.stream().map(item -> {
                OrdersDto ordersDto = new OrdersDto();
                BeanUtils.copyProperties(item,ordersDto);
                ordersDto.setUser(userService.getById(item.getUserid()));
                ordersDto.setGoods(goodsService.getById(item.getGoodsid()));
                ordersDto.setAddress(addressService.getById(item.getAddressid()));
                return ordersDto;
            }).collect(Collectors.toList());
            return Result.success(collect);
        }
        return Result.error("暂时没有数据");
    }



    @ApiOperation("通过id获取订单的方法")
    @PostMapping("/getById")
    public Result<OrderGoodsDto> getById(Integer id) {
        log.info("获取所有订单:");
        Orders orders = ordersService.getById(id);
        OrderGoodsDto orderGoodsDto = new OrderGoodsDto();
        BeanUtils.copyProperties(orders, orderGoodsDto); // 对象拷贝
        // 通过商品id查询商品信息
        Goods goods = goodsService.getById(orders.getGoodsid());
        orderGoodsDto.setGoods(goods);

        if (orders!=null) {
            return Result.success(orderGoodsDto);
        }
        return Result.error("暂时没有数据");
    }



    @ApiOperation("按用户id获取订单的方法")
    @PostMapping("/getByUserId")
    public Result<List<OrderGoodsDto>> getByUserId(String userid) {
        log.info("按用户id获取订单:{}",userid);
        LambdaQueryWrapper<Orders> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(Orders::getUserid,userid);
        List<Orders> ordersList = ordersService.list(queryWrapper);

        // 根据商品id对订单数据进行封装
        List<OrderGoodsDto> list = ordersList.stream().map(item -> {
            OrderGoodsDto orderGoodsDto = new OrderGoodsDto();
            BeanUtils.copyProperties(item, orderGoodsDto); // 对象拷贝
            Goods goods = goodsService.getById(item.getGoodsid());
            orderGoodsDto.setGoods(goods);
            return orderGoodsDto;
        }).collect(Collectors.toList());

        if (list.size() > 0) {
            return Result.success(list);
        }
        return Result.error("暂时没有数据");
    }

    @ApiOperation("下单的方法")
    @PostMapping("/save")
    public Result<String> save(@RequestBody Orders orders) {
        log.info("下单:{}",orders);
        // 设置状态为发布状态
        orders.setState("1"); // 下单
        boolean isSave = ordersService.save(orders);
        if (isSave) {
            return Result.success("下单成功");
        }
        return Result.error("下单失败");
    }

    @ApiOperation("支付订单的方法")
    @PostMapping("/pay")
    public Result<String> pay(@RequestBody Orders orders) {
        log.info("支付:--{}--{}--{}--{}",orders.getUserid(),orders.getId(),orders.getGoodsid(),orders.getAddressid());
        // 设置状态为付款状态
        orders.setState("2"); // 付款
        boolean isSave = ordersService.updateById(orders);
        if (isSave) {
            return Result.success("支付成功");
        }
        return Result.error("支付失败");
    }

    @ApiOperation("确认收货的方法")
    @PostMapping("/confirmOrders")
    public Result<String> confirmOrders(@RequestBody Orders orders) {
        log.info("确认收货:{}",orders);
        // 设置状态为确认收货状态
        orders.setState("4"); // 确认收货
        boolean isSave = ordersService.updateById(orders);
        if (isSave) {
            return Result.success("收货成功");
        }
        return Result.error("收货失败");
    }

//    @ApiOperation("按分类/订单名称/描述搜索订单")
//    @PostMapping("/searchOrders")
//    public Result<List<Orders>> searchOrders(String type,String name,String des) {
//        log.info("搜索订单:{},{},{}",type,name,des);
//        LambdaQueryWrapper<Orders> queryWrapper = new LambdaQueryWrapper<>();
//        queryWrapper.like(Orders::getType, type)
//                .or().like(Orders::getName, name)
//                .or().like(Orders::getDescribes, des);
//        List<Orders> list = ordersService.list(queryWrapper);
//        if (list.size() > 0) {
//            return Result.success(list);
//        }
//        return Result.error("暂无数据");
//    }


}

