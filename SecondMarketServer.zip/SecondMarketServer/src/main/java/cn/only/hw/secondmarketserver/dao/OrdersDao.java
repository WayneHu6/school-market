package cn.only.hw.secondmarketserver.dao;

import cn.only.hw.secondmarketserver.entity.Orders;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * (Orders)表数据库访问层
 *
 * @author 户伟伟
 * @since 2022-10-08 11:22:44
 */
 @Mapper
public interface OrdersDao extends BaseMapper<Orders> {

}

