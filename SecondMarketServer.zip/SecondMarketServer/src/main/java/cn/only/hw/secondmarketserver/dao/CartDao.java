package cn.only.hw.secondmarketserver.dao;

import cn.only.hw.secondmarketserver.entity.Cart;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * (Cart)表数据库访问层
 *
 * @author 户伟伟
 * @since 2022-10-06 11:15:35
 */
 @Mapper
public interface CartDao extends BaseMapper<Cart> {

}

