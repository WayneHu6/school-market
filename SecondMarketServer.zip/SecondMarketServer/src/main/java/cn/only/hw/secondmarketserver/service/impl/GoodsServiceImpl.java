package cn.only.hw.secondmarketserver.service.impl;

import cn.only.hw.secondmarketserver.entity.Goods;
import cn.only.hw.secondmarketserver.dao.GoodsDao;
import cn.only.hw.secondmarketserver.service.GoodsService;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


/**
 * (Goods)表服务实现类
 *
 * @author 户伟伟
 * @since 2022-10-03 16:23:00
 */
@Service
public class GoodsServiceImpl extends ServiceImpl<GoodsDao,Goods> implements GoodsService {
    @Autowired
    private GoodsDao goodsDao;

    @Override
    public List<Goods> getByType(String type) {
        LambdaQueryWrapper<Goods> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(Goods::getType,type);
        List<Goods> list = goodsDao.selectList(queryWrapper);
        return list;
    }

}
