package cn.only.hw.secondmarketserver.service;

import cn.only.hw.secondmarketserver.entity.Forum;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * (Forum)表服务接口
 *
 * @author 户伟伟
 * @since 2022-10-02 18:37:35
 */
public interface ForumService extends IService<Forum>{

    List<Forum> getByType(String type);
}
