package cn.only.hw.secondmarketserver.service;

import cn.only.hw.secondmarketserver.entity.Collect;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * (Collect)表服务接口
 *
 * @author 户伟伟
 * @since 2022-10-08 18:40:26
 */
public interface CollectService extends IService<Collect>{

}
