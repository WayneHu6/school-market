package cn.only.hw.secondmarketserver.dao;

import cn.only.hw.secondmarketserver.entity.Address;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * (Address)表数据库访问层
 *
 * @author 户伟伟
 * @since 2022-10-06 18:01:52
 */
 @Mapper
public interface AddressDao extends BaseMapper<Address> {

}

