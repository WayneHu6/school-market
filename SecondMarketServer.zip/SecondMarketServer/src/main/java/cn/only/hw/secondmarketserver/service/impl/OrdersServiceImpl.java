package cn.only.hw.secondmarketserver.service.impl;

import cn.only.hw.secondmarketserver.entity.Orders;
import cn.only.hw.secondmarketserver.dao.OrdersDao;
import cn.only.hw.secondmarketserver.service.OrdersService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;


/**
 * (Orders)表服务实现类
 *
 * @author 户伟伟
 * @since 2022-10-08 11:22:44
 */
@Service
public class OrdersServiceImpl extends ServiceImpl<OrdersDao,Orders> implements OrdersService {
 
}
