package cn.only.hw.secondmarketserver.service.impl;

import cn.only.hw.secondmarketserver.entity.Menu;
import cn.only.hw.secondmarketserver.dao.MenuDao;
import cn.only.hw.secondmarketserver.service.MenuService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;


/**
 * (Menu)表服务实现类
 *
 * @author 户伟伟
 * @since 2022-10-02 02:03:04
 */
@Service
public class MenuServiceImpl extends ServiceImpl<MenuDao,Menu> implements MenuService {
 
}
