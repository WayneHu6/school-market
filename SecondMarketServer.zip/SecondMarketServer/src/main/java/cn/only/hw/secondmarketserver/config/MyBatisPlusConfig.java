package cn.only.hw.secondmarketserver.config;

import com.baomidou.mybatisplus.extension.plugins.MybatisPlusInterceptor;
import com.baomidou.mybatisplus.extension.plugins.inner.PaginationInnerInterceptor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * 作者          ：户伟伟
 * 创建日期       ：Created in 2022/8/30 14:55
 * 描述          ：mybatis plus配置文件
 * 类名          ：MyBatisPlusConfig
 */

@Configuration
public class MyBatisPlusConfig {

    // 配置MP的分页工具
    @Bean
    public MybatisPlusInterceptor mybatisPlusInterceptor(){
        MybatisPlusInterceptor mybatisPlusInterceptor = new MybatisPlusInterceptor();
        mybatisPlusInterceptor.addInnerInterceptor(new PaginationInnerInterceptor());
        return mybatisPlusInterceptor;
    }
}
