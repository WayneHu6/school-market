package cn.only.hw.secondmarketserver.service;

import cn.only.hw.secondmarketserver.entity.Address;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * (Address)表服务接口
 *
 * @author 户伟伟
 * @since 2022-10-06 18:01:52
 */
public interface AddressService extends IService<Address>{

}
