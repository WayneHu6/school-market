package cn.only.hw.secondmarketserver.service.impl;

import cn.only.hw.secondmarketserver.entity.Cart;
import cn.only.hw.secondmarketserver.dao.CartDao;
import cn.only.hw.secondmarketserver.service.CartService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;


/**
 * (Cart)表服务实现类
 *
 * @author 户伟伟
 * @since 2022-10-06 11:15:35
 */
@Service
public class CartServiceImpl extends ServiceImpl<CartDao,Cart> implements CartService {
 
}
