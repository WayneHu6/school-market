package cn.only.hw.secondmarketserver.service.impl;

import cn.only.hw.secondmarketserver.entity.Collect;
import cn.only.hw.secondmarketserver.dao.CollectDao;
import cn.only.hw.secondmarketserver.service.CollectService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;


/**
 * (Collect)表服务实现类
 *
 * @author 户伟伟
 * @since 2022-10-08 18:40:26
 */
@Service
public class CollectServiceImpl extends ServiceImpl<CollectDao,Collect> implements CollectService {
 
}
