package cn.only.hw.secondmarketserver.controller;

import cn.only.hw.secondmarketserver.entity.*;
import cn.only.hw.secondmarketserver.service.*;
import cn.only.hw.secondmarketserver.util.BaseContext;
import cn.only.hw.secondmarketserver.util.Result;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import io.swagger.models.auth.In;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import io.swagger.annotations.Api;

import javax.servlet.http.HttpSession;
import java.util.List;
import java.util.UUID;


/**
 * (Manager)表控制层
 *
 * @author 户伟伟
 * @since 2022-10-03 16:43:47
 */
@RestController
@RequestMapping("/manager")
@Slf4j
@Api(tags = "Manager")
public class ManagerController {
    /**
     * 服务对象
     */
    @Autowired
    private ManagerService managerService;
    @Autowired
    private UserService userService;
    @Autowired
    private BannerService bannerService;
    @Autowired
    private NoticeService noticeService;
    @Autowired
    private MenuService menuService;
    @Autowired
    private CategoryService categoryService;
    @Autowired
    private CatechildService catechildService;
    @Autowired
    private GoodsService goodsService;
    @Autowired
    private ForumService forumService;

    @ApiOperation("管理员登录的方法")
    @ApiImplicitParam(name = "user", value = "登录信息", required = true)
    @PostMapping("/login")
    public Result<Manager> login(@RequestBody Manager manager, HttpSession session) {
        log.info("登录:{}",manager);
        Manager loginUser = managerService.login(manager);
        if (loginUser != null) {
            // 保存用户登录信息
            session.setAttribute("user", loginUser.getId());
            return Result.success(loginUser);
        }
        return Result.error("登录失败");
    }


    /*
    *
    *
    *
    *
    * 用户管理
    *
    *
    *
    *
    * */

    @ApiOperation("管理员获取所有用户的方法")
    @ApiImplicitParam(name = "user", value = "登录信息", required = true)
    @PostMapping("/getAllUser")
    public Result<List<User>> getAllUser() {
        log.info("获取所有用户信息:");
        List<User> list = userService.list();
        if (list.size() > 0) {
            return Result.success(list);
        }
        return Result.error("暂无数据");
    }

    @ApiOperation("管理员编辑用户信息的方法")
    @ApiImplicitParam(name = "user", value = "被管理的用户信息", required = true)
    @PostMapping("/editUser")
    public Result<String> editUser(@RequestBody User user) {
        log.info("编辑用户信息:{}",user);
        boolean isDone = userService.updateById(user);
        if (isDone) {
            return Result.success("编辑成功");
        }
        return Result.error("编辑失败");
    }

    @ApiOperation("管理员删除用户信息的方法")
    @ApiImplicitParam(name = "user", value = "被管理的用户信息", required = true)
    @PostMapping("/delUser")
    public Result<String> delUser(@RequestBody User user) {
        log.info("删除用户信息:{}",user);
        boolean isDone = userService.removeById(user);
        if (isDone) {
            return Result.success("删除成功");
        }
        return Result.error("删除失败");
    }


    @ApiOperation("管理员添加用户的方法")
    @ApiImplicitParam(name = "user", value = "被管理的用户信息", required = true)
    @PostMapping("/addUser")
    public Result<String> addUser(@RequestBody User user) {
        log.info("添加用户信息:{}",user);
        user.setIcon("https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fc-ssl.duitang.com%2Fuploads%2Fblog%2F202107%2F09%2F20210709142454_dc8dc.thumb.1000_0.jpeg&refer=http%3A%2F%2Fc-ssl.duitang.com&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=auto?sec=1667366231&t=f3680fb12f892a66c704ee8f6ab444ae");
        user.setNickname("某人");
        boolean isDone = userService.save(user);
        if (isDone) {
            return Result.success("添加成功");
        }
        return Result.error("添加失败");
    }

    @ApiOperation("管理员按照电话号码查询用户的方法")
    @ApiImplicitParam(name = "user", value = "被管理用户信息", required = true)
    @PostMapping("/getUserByTel")
    public Result<List<User>> getUserByTel(@RequestBody User user) {
        log.info("获取所有用户信息:");
        LambdaQueryWrapper<User> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.like(User::getTel,user.getTel());
        List<User> list = userService.list(queryWrapper);
        if (list.size() > 0) {
            return Result.success(list);
        }
        return Result.error("暂无数据");
    }




    /*
     *
     *
     *
     *
     * 轮播图管理
     *
     *
     *
     *
     * */

    @ApiOperation("管理员获取所有轮播图的方法")
    @ApiImplicitParam(name = "banner", value = "登录信息", required = true)
    @PostMapping("/getAllBanner")
    public Result<List<Banner>> getAllBanner() {
        log.info("获取所有轮播图信息:");
        List<Banner> list = bannerService.list();
        if (list.size() > 0) {
            return Result.success(list);
        }
        return Result.error("暂无数据");
    }

    @ApiOperation("管理员编辑轮播图信息的方法")
    @ApiImplicitParam(name = "banner", value = "被管理的轮播图信息", required = true)
    @PostMapping("/editBanner")
    public Result<String> editBanner(@RequestBody Banner banner) {
        log.info("编辑轮播图信息:{}",banner);
        boolean isDone = bannerService.updateById(banner);
        if (isDone) {
            return Result.success("编辑成功");
        }
        return Result.error("编辑失败");
    }

    @ApiOperation("管理员删除轮播图信息的方法")
    @ApiImplicitParam(name = "banner", value = "被管理的轮播图信息", required = true)
    @PostMapping("/delBanner")
    public Result<String> delBanner(@RequestBody Banner banner) {
        log.info("删除轮播图信息:{}",banner);
        boolean isDone = bannerService.removeById(banner);
        if (isDone) {
            return Result.success("删除成功");
        }
        return Result.error("删除失败");
    }


    @ApiOperation("管理员添加轮播图的方法")
    @ApiImplicitParam(name = "banner", value = "被管理的轮播图信息", required = true)
    @PostMapping("/addBanner")
    public Result<String> addBanner(@RequestBody Banner banner) {
        log.info("添加轮播图信息:{}",banner);
//        banner.setSendUser(String.valueOf(BaseContext.getCurrentId()));
        boolean isDone = bannerService.save(banner);
        if (isDone) {
            return Result.success("添加成功");
        }
        return Result.error("添加失败");
    }


    /*
     *
     *
     *
     *
     * 通知公告管理
     *
     *
     *
     *
     * */

    @ApiOperation("管理员获取所有通知公告的方法")
    @ApiImplicitParam(name = "notice", value = "登录信息", required = true)
    @PostMapping("/getAllNotice")
    public Result<List<Notice>> getAllNotice() {
        log.info("获取所有通知公告信息:");
        List<Notice> list = noticeService.list();
        if (list.size() > 0) {
            return Result.success(list);
        }
        return Result.error("暂无数据");
    }

    @ApiOperation("管理员编辑通知公告信息的方法")
    @ApiImplicitParam(name = "notice", value = "被管理的通知公告信息", required = true)
    @PostMapping("/editNotice")
    public Result<String> editNotice(@RequestBody Notice notice) {
        log.info("编辑通知公告信息:{}",notice);
        boolean isDone = noticeService.updateById(notice);
        if (isDone) {
            return Result.success("编辑成功");
        }
        return Result.error("编辑失败");
    }

    @ApiOperation("管理员删除通知公告信息的方法")
    @ApiImplicitParam(name = "notice", value = "被管理的通知公告信息", required = true)
    @PostMapping("/delNotice")
    public Result<String> delNotice(@RequestBody Notice notice) {
        log.info("删除通知公告信息:{}",notice);
        boolean isDone = noticeService.removeById(notice);
        if (isDone) {
            return Result.success("删除成功");
        }
        return Result.error("删除失败");
    }


    @ApiOperation("管理员添加通知公告的方法")
    @ApiImplicitParam(name = "notice", value = "被管理的通知公告信息", required = true)
    @PostMapping("/addNotice")
    public Result<String> addNotice(@RequestBody Notice notice) {
        log.info("添加通知公告信息:{}",notice);
//        notice.setSendUser(BaseContext.getCurrentId());
        boolean isDone = noticeService.save(notice);
        if (isDone) {
            return Result.success("添加成功");
        }
        return Result.error("添加失败");
    }

    @ApiOperation("管理员按照内容查询通知公告的方法")
    @ApiImplicitParam(name = "notice", value = "被管理通知公告信息", required = true)
    @PostMapping("/getNoticeByContent")
    public Result<List<Notice>> getNoticeByContent(@RequestBody Notice notice) {
        log.info("获取所有通知公告信息:");
        LambdaQueryWrapper<Notice> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.like(Notice::getContent,notice.getContent());
        List<Notice> list = noticeService.list(queryWrapper);
        if (list.size() > 0) {
            return Result.success(list);
        }
        return Result.error("暂无数据");
    }


    /*
     *
     *
     *
     *
     * 菜单管理
     *
     *
     *
     *
     * */

    @ApiOperation("管理员获取所有菜单的方法")
    @ApiImplicitParam(name = "menu", value = "登录信息", required = true)
    @PostMapping("/getAllMenu")
    public Result<List<Menu>> getAllMenu() {
        log.info("获取所有菜单信息:");
        List<Menu> list = menuService.list();
        if (list.size() > 0) {
            return Result.success(list);
        }
        return Result.error("暂无数据");
    }

    @ApiOperation("管理员编辑菜单信息的方法")
    @ApiImplicitParam(name = "menu", value = "被管理的菜单信息", required = true)
    @PostMapping("/editMenu")
    public Result<String> editMenu(@RequestBody Menu menu) {
        log.info("编辑菜单信息:{}",menu);
        boolean isDone = menuService.updateById(menu);
        if (isDone) {
            return Result.success("编辑成功");
        }
        return Result.error("编辑失败");
    }

    @ApiOperation("管理员删除菜单信息的方法")
    @ApiImplicitParam(name = "menu", value = "被管理的菜单信息", required = true)
    @PostMapping("/delMenu")
    public Result<String> delMenu(@RequestBody Menu menu) {
        log.info("删除菜单信息:{}",menu);
        boolean isDone = menuService.removeById(menu);
        if (isDone) {
            return Result.success("删除成功");
        }
        return Result.error("删除失败");
    }


    @ApiOperation("管理员添加菜单的方法")
    @ApiImplicitParam(name = "menu", value = "被管理的菜单信息", required = true)
    @PostMapping("/addMenu")
    public Result<String> addMenu(@RequestBody Menu menu) {
        log.info("添加菜单信息:{}",menu);
//        menu.setSendUser(BaseContext.getCurrentId());
        boolean isDone = menuService.save(menu);
        if (isDone) {
            return Result.success("添加成功");
        }
        return Result.error("添加失败");
    }



    /*
     *
     *
     *
     *
     * 分类管理
     *
     *
     *
     *
     * */

    @ApiOperation("管理员获取所有分类的方法")
    @ApiImplicitParam(name = "category", value = "登录信息", required = true)
    @PostMapping("/getAllCategory")
    public Result<List<Category>> getAllCategory() {
        log.info("获取所有分类信息:");
        List<Category> list = categoryService.list();
        if (list.size() > 0) {
            return Result.success(list);
        }
        return Result.error("暂无数据");
    }

    @ApiOperation("管理员编辑分类信息的方法")
    @ApiImplicitParam(name = "category", value = "被管理的分类信息", required = true)
    @PostMapping("/editCategory")
    public Result<String> editCategory(@RequestBody Category category) {
        log.info("编辑分类信息:{}",category);
        boolean isDone = categoryService.updateById(category);
        if (isDone) {
            return Result.success("编辑成功");
        }
        return Result.error("编辑失败");
    }

    @ApiOperation("管理员删除分类信息的方法")
    @ApiImplicitParam(name = "category", value = "被管理的分类信息", required = true)
    @PostMapping("/delCategory")
    public Result<String> delCategory(@RequestBody Category category) {
        log.info("删除分类信息:{}",category);
        boolean isDone = categoryService.removeById(category);
        if (isDone) {
            return Result.success("删除成功");
        }
        return Result.error("删除失败");
    }


    @ApiOperation("管理员添加分类的方法")
    @ApiImplicitParam(name = "category", value = "被管理的分类信息", required = true)
    @PostMapping("/addCategory")
    public Result<String> addCategory(@RequestBody Category category) {
        log.info("添加分类信息:{}",category);
//        category.setSendUser(BaseContext.getCurrentId());
//        category.setCateid(UUID.randomUUID().toString());
        boolean isDone = categoryService.save(category);
        if (isDone) {
            return Result.success("添加成功");
        }
        return Result.error("添加失败");
    }



    /*
     *
     *
     *
     *
     * 分类所属商品管理
     *
     *
     *
     *
     * */

    @ApiOperation("管理员获取所有分类所属商品的方法")
    @ApiImplicitParam(name = "catechild", value = "登录信息", required = true)
    @PostMapping("/getAllCatechild")
    public Result<List<Catechild>> getAllCatechild() {
        log.info("获取所有分类所属商品信息:");
        List<Catechild> list = catechildService.list();
        if (list.size() > 0) {
            return Result.success(list);
        }
        return Result.error("暂无数据");
    }

    @ApiOperation("管理员编辑分类所属商品信息的方法")
    @ApiImplicitParam(name = "catechild", value = "被管理的分类所属商品信息", required = true)
    @PostMapping("/editCatechild")
    public Result<String> editCatechild(@RequestBody Catechild catechild) {
        log.info("编辑分类所属商品信息:{}",catechild);
        boolean isDone = catechildService.updateById(catechild);
        if (isDone) {
            return Result.success("编辑成功");
        }
        return Result.error("编辑失败");
    }

    @ApiOperation("管理员删除分类所属商品信息的方法")
    @ApiImplicitParam(name = "catechild", value = "被管理的分类所属商品信息", required = true)
    @PostMapping("/delCatechild")
    public Result<String> delCatechild(@RequestBody Catechild catechild) {
        log.info("删除分类所属商品信息:{}",catechild);
        boolean isDone = catechildService.removeById(catechild);
        if (isDone) {
            return Result.success("删除成功");
        }
        return Result.error("删除失败");
    }


    @ApiOperation("管理员添加分类所属商品的方法")
    @ApiImplicitParam(name = "catechild", value = "被管理的分类所属商品信息", required = true)
    @PostMapping("/addCatechild")
    public Result<String> addCatechild(String cateid,String goodsid) {
        log.info("添加分类所属商品信息:{}{}",cateid,goodsid);
        // 获取商品信息
        Goods goods = goodsService.getById(goodsid);
        Catechild catechild = new Catechild();
        catechild.setCateid(Integer.valueOf(cateid));
        catechild.setGoodid(goodsid);
        catechild.setImage(goods.getIcon());
        catechild.setChildname(goods.getName());

        boolean isDone = catechildService.save(catechild);
        if (isDone) {
            return Result.success("添加成功");
        }
        return Result.error("添加失败");
    }






    /*
     *
     *
     *
     *
     * 商品管理
     *
     *
     *
     *
     * */

    @ApiOperation("管理员获取所有商品的方法")
    @ApiImplicitParam(name = "goods", value = "登录信息", required = true)
    @PostMapping("/getAllGoods")
    public Result<List<Goods>> getAllGoods() {
        log.info("获取所有商品信息:");
        List<Goods> list = goodsService.list();
        if (list.size() > 0) {
            return Result.success(list);
        }
        return Result.error("暂无数据");
    }

    @ApiOperation("管理员编辑商品信息的方法")
    @ApiImplicitParam(name = "goods", value = "被管理的商品信息", required = true)
    @PostMapping("/editGoods")
    public Result<String> editGoods(@RequestBody Goods goods) {
        log.info("编辑商品信息:{}",goods);
        boolean isDone = goodsService.updateById(goods);
        if (isDone) {
            return Result.success("编辑成功");
        }
        return Result.error("编辑失败");
    }

    @ApiOperation("管理员删除商品信息的方法")
    @ApiImplicitParam(name = "goods", value = "被管理的商品信息", required = true)
    @PostMapping("/delGoods")
    public Result<String> delGoods(@RequestBody Goods goods) {
        log.info("删除商品信息:{}",goods);
        boolean isDone = goodsService.removeById(goods);
        if (isDone) {
            return Result.success("删除成功");
        }
        return Result.error("删除失败");
    }


    @ApiOperation("管理员添加商品的方法")
    @ApiImplicitParam(name = "goods", value = "被管理的商品信息", required = true)
    @PostMapping("/addGoods")
    public Result<String> addGoods(@RequestBody Goods goods) {
        log.info("添加商品信息:{}",goods);
//        goods.setSendUser(BaseContext.getCurrentId());
        boolean isDone = goodsService.save(goods);
        if (isDone) {
            return Result.success("添加成功");
        }
        return Result.error("添加失败");
    }

    @ApiOperation("管理员按照商品名称查询商品的方法")
    @ApiImplicitParam(name = "goods", value = "被管理商品信息", required = true)
    @PostMapping("/getGoodsByName")
    public Result<List<Goods>> getGoodsByName(@RequestBody Goods goods) {
        log.info("获取所有商品信息:");
        LambdaQueryWrapper<Goods> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.like(Goods::getName,goods.getName());
        List<Goods> list = goodsService.list(queryWrapper);
        if (list.size() > 0) {
            return Result.success(list);
        }
        return Result.error("暂无数据");
    }


    @ApiOperation("管理员审核的方法")
    @PostMapping("/checkGoods")
    public Result<String> checkGoods(Integer id, String manage) {
        log.info("管理员审核的方法:{},{}",id,manage);
      Goods goods = new Goods();
      goods.setId(id);
      goods.setManage(manage);
        boolean b = goodsService.updateById(goods);
        if (b) {
            return Result.success("操作成功");
        }
        return Result.error("操作失败");
    }



    /*
     *
     *
     *
     *
     * 论坛帖子管理
     *
     *
     *
     *
     * */

    @ApiOperation("管理员获取所有论坛帖子的方法")
    @ApiImplicitParam(name = "forum", value = "登录信息", required = true)
    @PostMapping("/getAllForum")
    public Result<List<Forum>> getAllForum() {
        log.info("获取所有论坛帖子信息:");
        List<Forum> list = forumService.list();
        if (list.size() > 0) {
            return Result.success(list);
        }
        return Result.error("暂无数据");
    }

    @ApiOperation("管理员编辑论坛帖子信息的方法")
    @ApiImplicitParam(name = "forum", value = "被管理的论坛帖子信息", required = true)
    @PostMapping("/editForum")
    public Result<String> editForum(@RequestBody Forum forum) {
        log.info("编辑论坛帖子信息:{}",forum);
        boolean isDone = forumService.updateById(forum);
        if (isDone) {
            return Result.success("编辑成功");
        }
        return Result.error("编辑失败");
    }

    @ApiOperation("管理员删除论坛帖子信息的方法")
    @ApiImplicitParam(name = "forum", value = "被管理的论坛帖子信息", required = true)
    @PostMapping("/delForum")
    public Result<String> delForum(@RequestBody Forum forum) {
        log.info("删除论坛帖子信息:{}",forum);
        boolean isDone = forumService.removeById(forum);
        if (isDone) {
            return Result.success("删除成功");
        }
        return Result.error("删除失败");
    }


    @ApiOperation("管理员添加论坛帖子的方法")
    @ApiImplicitParam(name = "forum", value = "被管理的论坛帖子信息", required = true)
    @PostMapping("/addForum")
    public Result<String> addForum(@RequestBody Forum forum) {
        log.info("添加论坛帖子信息:{}",forum);
//        forum.setSendUser(BaseContext.getCurrentId());
        boolean isDone = forumService.save(forum);
        if (isDone) {
            return Result.success("添加成功");
        }
        return Result.error("添加失败");
    }

    @ApiOperation("管理员按照内容查询论坛帖子的方法")
    @ApiImplicitParam(name = "forum", value = "被管理论坛帖子信息", required = true)
    @PostMapping("/getForumByContent")
    public Result<List<Forum>> getForumByContent(@RequestBody Forum forum) {
        log.info("获取所有论坛帖子信息:");
        LambdaQueryWrapper<Forum> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.like(Forum::getContent,forum.getContent());
        List<Forum> list = forumService.list(queryWrapper);
        if (list.size() > 0) {
            return Result.success(list);
        }
        return Result.error("暂无数据");
    }

    @ApiOperation("管理员审核帖子的方法")
    @PostMapping("/checkForum")
    public Result<String> checkForum(Integer id, String manage) {
        log.info("管理员审核帖子的方法:{},{}",id,manage);
        Forum forum = new Forum();
        forum.setId(id);
        forum.setManage(manage);
        boolean b = forumService.updateById(forum);
        if (b) {
            return Result.success("操作成功");
        }
        return Result.error("操作失败");
    }









}

