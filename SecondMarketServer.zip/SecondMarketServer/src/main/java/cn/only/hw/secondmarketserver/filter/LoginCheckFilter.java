package cn.only.hw.secondmarketserver.filter;

import cn.only.hw.secondmarketserver.util.BaseContext;
import cn.only.hw.secondmarketserver.util.Result;
import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.AntPathMatcher;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;


/**
 * 作者          ：户伟伟
 * 创建日期       ：Created in 2022/8/30 12:38
 * 描述          ：
 * 类名          ：LoginCheckFilter
 */

//@WebFilter(filterName = "loginCheckFilter",urlPatterns = "/*")
@Slf4j
public class LoginCheckFilter implements Filter {



    // 路径匹配器 支持通配符
    public static final AntPathMatcher PATH_MATCHER = new AntPathMatcher();
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest httpServletRequest = (HttpServletRequest) request;
        HttpServletResponse httpServletResponse = (HttpServletResponse) response;

        String requestURI = httpServletRequest.getRequestURI();
        log.info("拦截到请求:{}",requestURI);

        String[] urls = {
                "/employee/login",
                "/employee/logout",
                "/backend/**",
                "/front/**",
                "/common/**",
                "/user/sendMsg",
                "/user/login",
                "/user/register",
                "/doc.html",
                "/webjars/**",
                "/swagger-resources",
                "/v2/api-docs",
        };
        // 判断路径是否需要处理
        boolean check = check(urls, requestURI);
        if (check){
            // 直接放行
            log.info("本次请求不需要处理:{}",requestURI);
            chain.doFilter(request,response);
            return;
        }
        // 检查是否登录--web
        if (httpServletRequest.getSession().getAttribute("employee") != null){
            // 已经登录
            // 直接放行
            log.info("用户已登录,用户id为:{}",httpServletRequest.getSession().getAttribute("employee"));
            int empId = (int) httpServletRequest.getSession().getAttribute("employee");
            BaseContext.setCurrentId(empId);
            chain.doFilter(request,response);
            return;
        }

        // 检查是否登录--phone
        if (httpServletRequest.getSession().getAttribute("user") != null){
            // 已经登录
            // 直接放行
            log.info("用户已登录,用户id为:{}",httpServletRequest.getSession().getAttribute("user"));
            int userId = (int) httpServletRequest.getSession().getAttribute("user");
            BaseContext.setCurrentId(userId);
            chain.doFilter(request,response);
            return;
        }
        // 未登录 通过输出流向客户端响应数据
        log.info("用户未登录:{}",requestURI);
        httpServletResponse.getWriter().write(JSON.toJSONString(Result.error("NOTLOGIN")));
        return;


    }




    public boolean check(String[] urls,String requestURI){
        for (String url:urls) {
            boolean match = PATH_MATCHER.match(url, requestURI);
            if (match){
                return true;
            }
        }
        return false;
    }
}
