package cn.only.hw.secondmarketserver.dto;

import cn.only.hw.secondmarketserver.entity.Collect;
import cn.only.hw.secondmarketserver.entity.Goods;
import lombok.Data;

/**
 * 作者          : 户伟伟
 * 创建日期       : Created in 2022/10/8 19:21
 * 描述          : TODO
 * 类名          : CollectGoodsDto
 */

@Data
public class CollectGoodsDto extends Collect {
    private Goods goods = new Goods();

}
