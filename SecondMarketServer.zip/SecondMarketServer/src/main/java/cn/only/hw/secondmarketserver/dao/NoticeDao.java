package cn.only.hw.secondmarketserver.dao;

import cn.only.hw.secondmarketserver.entity.Notice;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * (Notice)表数据库访问层
 *
 * @author 户伟伟
 * @since 2022-10-02 02:23:14
 */
 @Mapper
public interface NoticeDao extends BaseMapper<Notice> {

}

