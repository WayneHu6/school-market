package cn.only.hw.secondmarketserver.service;

import cn.only.hw.secondmarketserver.entity.User;
import cn.only.hw.secondmarketserver.util.Result;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * (User)表服务接口
 *
 * @author 户伟伟
 * @since 2022-10-03 13:21:38
 */
public interface UserService extends IService<User>{

    User login(User user);

    Result<String> register(User user);
}
