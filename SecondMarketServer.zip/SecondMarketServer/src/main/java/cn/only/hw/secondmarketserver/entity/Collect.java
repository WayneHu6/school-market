package cn.only.hw.secondmarketserver.entity;

import java.util.Date;
import java.io.Serializable;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * (Collect)实体类
 *
 * @author 户伟伟
 * @since 2022-10-08 19:18:10
 */
@ApiModel("Collect")
public class Collect implements Serializable {
    private static final long serialVersionUID = -51898547986564885L;
    
        
    private Integer id;
    /**
     * 收藏类型(0商品 1帖子)
     */
    @ApiModelProperty("收藏类型(0商品 1帖子)")    
    private String type;
    /**
     * 用户id
     */
    @ApiModelProperty("用户id")    
    private Integer userid;
    /**
     * 帖子或商品id
     */
    @ApiModelProperty("帖子或商品id")    
    private Integer sid;
    /**
     * 收藏时间
     */
    @ApiModelProperty("收藏时间")
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private Date updateTime;
    @ApiModelProperty("收藏时间")
    @TableField(fill = FieldFill.INSERT)
    private Date sendTime;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Integer getUserid() {
        return userid;
    }

    public void setUserid(Integer userid) {
        this.userid = userid;
    }

    public Integer getSid() {
        return sid;
    }

    public void setSid(Integer sid) {
        this.sid = sid;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Date getSendTime() {
        return sendTime;
    }

    public void setSendTime(Date sendTime) {
        this.sendTime = sendTime;
    }

}

