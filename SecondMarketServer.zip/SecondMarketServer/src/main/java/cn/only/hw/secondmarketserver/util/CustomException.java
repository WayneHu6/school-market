package cn.only.hw.secondmarketserver.util;

/**
 * 作者          ：户伟伟
 * 创建日期       ：Created in 2022/9/19 12:49
 * 描述          ：TODO 自定义业务异常类
 * 类名          ：CustomException
 */
public class CustomException extends RuntimeException{
    public CustomException(String msg){
        super(msg);

    }
}
