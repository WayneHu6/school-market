package cn.only.hw.secondmarketserver.controller;

import cn.only.hw.secondmarketserver.entity.Forum;
import cn.only.hw.secondmarketserver.entity.Forum;
import cn.only.hw.secondmarketserver.service.ForumService;
import cn.only.hw.secondmarketserver.util.Result;
import com.alibaba.fastjson.JSONArray;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import io.swagger.annotations.Api;

import java.util.Arrays;
import java.util.List;


/**
 * (Forum)表控制层
 *
 * @author 户伟伟
 * @since 2022-10-02 18:37:35
 */
@RestController
@RequestMapping("/forum")
@Slf4j
@Api(tags = "论坛相关操作")
public class ForumController {
    /**
     * 服务对象
     */
    @Autowired
    private ForumService forumService;

    @ApiOperation("获取所有论坛帖子的方法")
    @PostMapping("/list")
    public Result<List<Forum>> login() {
        log.info("获取所有帖子:");
        List<Forum> list = forumService.list();
        if (list.size() > 0) {
            return Result.success(list);
        }
        return Result.error("暂时没有数据");
    }


    @ApiOperation("通过id获取帖子的方法")
    @PostMapping("/getById")
    public Result<Forum> getById(Integer id) {
        log.info("获取所有帖子:");
        Forum forum = forumService.getById(id);
        if (forum != null) {
            // 对多张图片数据进行处理
            String[] imgStrs = forum.getImgs().split(",");
            JSONArray jsonArray = new JSONArray(Arrays.asList(imgStrs));
            return Result.success(forum).add("imgs",jsonArray);
        }
        return Result.error("暂时没有数据");
    }

    @ApiOperation("通过用户id获取帖子的方法")
    @PostMapping("/getByUserId")
    public Result<List<Forum>> getByUserId(Integer userid) {
        log.info("获取帖子:{}",userid);
        LambdaQueryWrapper<Forum> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(Forum::getSendUser,userid);
        List<Forum> list = forumService.list(queryWrapper);
        if (list.size()>0) {
            return Result.success(list);
        }
        return Result.error("暂时没有数据");
    }




    @ApiOperation("按类型获取帖子的方法")
    @PostMapping("/getByType")
    public Result<List<Forum>> getByType(String type) {
        log.info("获取所有帖子:");
        List<Forum> list = forumService.getByType(type);
        if (list.size() > 0) {
            return Result.success(list);
        }
        return Result.error("暂时没有数据");
    }

    @ApiOperation("删除帖子的方法")
    @PostMapping("/del")
    public Result<String> del(String id) {
        log.info("删除帖子:{}",id);
        boolean b = forumService.removeById(id);
        if (b) {
            return Result.success("删除成功");
        }
        return Result.error("删除失败");
    }

    @ApiOperation("发布帖子的方法")
    @PostMapping("/save")
    public Result<String> save(@RequestBody Forum forum) {
        log.info("发布帖子:{}",forum);
        forum.setManage("0");
        boolean isUave = forumService.save(forum);
        if (isUave) {
            return Result.success("发布成功");
        }
        return Result.error("发布失败");
    }



    @ApiOperation("按类型/标题/内容/搜索帖子")
    @PostMapping("/searchForum")
    public Result<List<Forum>> searchForum(String type,String title,String content) {
        log.info("搜索帖子:{},{},{}",type,title,content);
        LambdaQueryWrapper<Forum> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.like(Forum::getType, type)
                .or().like(Forum::getTitle, title)
                .or().like(Forum::getContent, content);
        List<Forum> list = forumService.list(queryWrapper);
        if (list.size() > 0) {
            return Result.success(list);
        }
        return Result.error("暂无数据");
    }



}

