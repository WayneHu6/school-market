package cn.only.hw.secondmarketserver.service;

import cn.only.hw.secondmarketserver.entity.Category;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * (Category)表服务接口
 *
 * @author 户伟伟
 * @since 2022-10-02 03:03:22
 */
public interface CategoryService extends IService<Category>{

}
