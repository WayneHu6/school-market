package cn.only.hw.secondmarketserver.controller;

import cn.only.hw.secondmarketserver.entity.Goods;
import cn.only.hw.secondmarketserver.service.GoodsService;
import cn.only.hw.secondmarketserver.util.Result;
import com.alibaba.fastjson.JSONArray;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import io.swagger.annotations.Api;

import java.util.Arrays;
import java.util.List;


/**
 * (Goods)表控制层
 *
 * @author 户伟伟
 * @since 2022-10-03 16:23:00
 */
@RestController
@RequestMapping("/goods")
@Slf4j
@Api(tags = "Goods")
public class GoodsController {
    /**
     * 服务对象
     */
    @Autowired
    private GoodsService goodsService;

    @ApiOperation("获取所有商品的方法")
    @PostMapping("/list")
    public Result<List<Goods>> login() {
        log.info("获取所有商品:");
        List<Goods> list = goodsService.list();
        if (list.size() > 0) {
            return Result.success(list);
        }
        return Result.error("暂时没有数据");
    }


    @ApiOperation("通过id获取商品的方法")
    @PostMapping("/getById")
    public Result<Goods> getById(Integer id) {
        log.info("获取所有商品:");
        Goods goods = goodsService.getById(id);
        if (goods != null) {
            // 对多张图片数据进行处理
            String[] imgStrs = goods.getImgs().split(",");
            JSONArray jsonArray = new JSONArray(Arrays.asList(imgStrs));
            return Result.success(goods).add("imgs",jsonArray);
        }
        return Result.error("暂时没有数据");
    }



    @ApiOperation("按类型获取商品的方法")
    @PostMapping("/getByType")
    public Result<List<Goods>> getByType(String type) {
        log.info("获取所有商品:");
        List<Goods> list = goodsService.getByType(type);
        if (list.size() > 0) {
            return Result.success(list);
        }
        return Result.error("暂时没有数据");
    }

    @ApiOperation("发布商品/求购的方法")
    @PostMapping("/save")
    public Result<String> save(@RequestBody Goods goods) {
        log.info("发布商品:");
        // 设置状态为发布状态
        goods.setManage("0");
        boolean isSave = goodsService.save(goods);
        if (isSave) {
            return Result.success("发布成功");
        }
        return Result.error("发布失败");
    }


    @ApiOperation("按分类/商品名称/描述搜索商品")
    @PostMapping("/searchGoods")
    public Result<List<Goods>> searchGoods(String type,String name,String des) {
        log.info("搜索商品:{},{},{}",type,name,des);
        LambdaQueryWrapper<Goods> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.like(Goods::getType, type)
                .or().like(Goods::getName, name)
                .or().like(Goods::getDescribes, des);
        List<Goods> list = goodsService.list(queryWrapper);
        if (list.size() > 0) {
            return Result.success(list);
        }
        return Result.error("暂无数据");
    }


}

