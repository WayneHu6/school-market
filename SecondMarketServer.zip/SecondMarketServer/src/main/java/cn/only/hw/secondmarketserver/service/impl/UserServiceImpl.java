package cn.only.hw.secondmarketserver.service.impl;

import cn.only.hw.secondmarketserver.entity.User;
import cn.only.hw.secondmarketserver.dao.UserDao;
import cn.only.hw.secondmarketserver.service.UserService;
import cn.only.hw.secondmarketserver.util.Result;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


/**
 * (User)表服务实现类
 *
 * @author 户伟伟
 * @since 2022-10-03 13:21:38
 */
@Service
public class UserServiceImpl extends ServiceImpl<UserDao,User> implements UserService {
    @Autowired
    private UserDao userDao;

    @Override
    public User login(User user) {
        LambdaQueryWrapper<User> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(User::getAccount,user.getAccount());
        queryWrapper.eq(User::getPassword,user.getPassword());
        User userLogin = userDao.selectOne(queryWrapper);
        return userLogin;
    }

    @Override
    public Result<String> register(User user) {
        LambdaQueryWrapper<User> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(User::getAccount,user.getAccount());
        User one = userDao.selectOne(queryWrapper);
        if (one == null){
            userDao.insert(user);
            return Result.success("注册成功");
        }
        return Result.error("注册失败");
    }

}
