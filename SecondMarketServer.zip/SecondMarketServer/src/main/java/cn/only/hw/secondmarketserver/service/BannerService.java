package cn.only.hw.secondmarketserver.service;

import cn.only.hw.secondmarketserver.entity.Banner;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * (Banner)表服务接口
 *
 * @author 户伟伟
 * @since 2022-10-02 00:36:59
 */
public interface BannerService extends IService<Banner>{

}
