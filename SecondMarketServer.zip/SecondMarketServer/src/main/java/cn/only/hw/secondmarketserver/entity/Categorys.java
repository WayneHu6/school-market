package cn.only.hw.secondmarketserver.entity;

import java.util.List;

public class Categorys extends Category{
    List<Catechild> children;


    public List<Catechild> getChildren() {
        return children;
    }

    public void setChildren(List<Catechild> children) {
        this.children = children;
    }
}