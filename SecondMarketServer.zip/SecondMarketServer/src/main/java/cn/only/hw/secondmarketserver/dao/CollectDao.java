package cn.only.hw.secondmarketserver.dao;

import cn.only.hw.secondmarketserver.entity.Collect;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * (Collect)表数据库访问层
 *
 * @author 户伟伟
 * @since 2022-10-08 18:40:24
 */
 @Mapper
public interface CollectDao extends BaseMapper<Collect> {

}

