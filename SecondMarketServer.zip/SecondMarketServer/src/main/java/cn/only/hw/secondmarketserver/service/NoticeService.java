package cn.only.hw.secondmarketserver.service;

import cn.only.hw.secondmarketserver.entity.Notice;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * (Notice)表服务接口
 *
 * @author 户伟伟
 * @since 2022-10-02 02:23:14
 */
public interface NoticeService extends IService<Notice>{

}
