package cn.only.hw.secondmarketserver.service.impl;

import cn.only.hw.secondmarketserver.entity.Banner;
import cn.only.hw.secondmarketserver.dao.BannerDao;
import cn.only.hw.secondmarketserver.service.BannerService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;


/**
 * (Banner)表服务实现类
 *
 * @author 户伟伟
 * @since 2022-10-02 00:36:59
 */
@Service
public class BannerServiceImpl extends ServiceImpl<BannerDao,Banner> implements BannerService {
 
}
