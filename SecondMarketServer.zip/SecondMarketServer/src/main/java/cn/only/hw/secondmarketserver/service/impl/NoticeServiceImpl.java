package cn.only.hw.secondmarketserver.service.impl;

import cn.only.hw.secondmarketserver.entity.Notice;
import cn.only.hw.secondmarketserver.dao.NoticeDao;
import cn.only.hw.secondmarketserver.service.NoticeService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;


/**
 * (Notice)表服务实现类
 *
 * @author 户伟伟
 * @since 2022-10-02 02:23:14
 */
@Service
public class NoticeServiceImpl extends ServiceImpl<NoticeDao,Notice> implements NoticeService {
 
}
