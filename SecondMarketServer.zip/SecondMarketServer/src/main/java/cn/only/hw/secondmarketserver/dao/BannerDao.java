package cn.only.hw.secondmarketserver.dao;

import cn.only.hw.secondmarketserver.entity.Banner;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * (Banner)表数据库访问层
 *
 * @author 户伟伟
 * @since 2022-10-02 00:36:59
 */
 @Mapper
public interface BannerDao extends BaseMapper<Banner> {

}

