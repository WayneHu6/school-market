
function orders() {

	layui.use(['form', 'table'], function() {
		var $ = layui.jquery,
			form = layui.form,
			table = layui.table;
			
			

		var datas = {
			"token": window.localStorage.getItem("token"),
			"userid": window.localStorage.getItem("userid"),
		};

		$.ajax({
			url: baseurl + "orders/getAllOrder",
			data: JSON.stringify(datas),
			type: "post",
			dataType: "json",
			headers: {
				'Content-Type': 'application/json;charset=utf-8'
			}, //接口json格式
			success: function(data) {
				if (data.code == "1") {


					var d = data.data;

					table.render({
						elem: '#currentTableId',
						data: d,
						toolbar: '#toolbarDemo',
						defaultToolbar: ['filter', 'exports', 'print', {
							title: '提示',
							layEvent: 'LAYTABLE_TIPS',
							icon: 'layui-icon-tips'
						}],
						cols: [
							[{
									field: 'id',
									width: 240,
									title: '订单编号'
								},
								{
									field: 'pname',
									width: 300,
									title: '商品名称',
									align: "center",
									templet: function(data){
										
										return "<span>"+data.goods.name+"</span>";
									}
								},
								{
									field: 'pimg',
									width: 300,
									title: '商品图片',
									align: "center",
									templet:"#imgtmp",
								},
								
								{
									field: 'state',
									width: 120,
									title: '订单状态',
									align: "center",
									templet: function(data) {
										if (data.state == "5") {
											tmp = "订单取消";
											return "<span style='color:#55aaff'>" +
												tmp + "</span>";
										}
										if (data.state == "1") {
											tmp = "待付款";
											return "<span style='color:#55ff7f'>" +
												tmp + "</span>";
										}
										if (data.state == "2") {
											tmp = "待发货";
											return "<span style='color:#ff0000'>" +
												tmp + "</span>";
										}
										if (data.state == "3") {
											tmp = "待收货";
											return "<span style='color:#55ffff'>" +
												tmp + "</span>";
										}
										if (data.state == "4") {
											tmp = "已完成";
											return "<span style='color:#550000'>" +
												tmp + "</span>";
										}
									}
								
								},
								
								{
									field: 'uname',
									width: 120,
									title: '用户名',
									align: "center"
								},
								
								{
									field: 'price',
									width: 120,
									title: '实际支付',
									align: "center"
								},
								
								{
									field: 'sendTime',
									width: 240,
									title: '日期',
									align: "center"
								},
								{
									title: '操作',
									minWidth: 200,
									toolbar: '#currentTableBar',
									align: "center"
								}
							]
						],
						limits: [10, 15, 20, 25, 50, 100],
						limit: d.length,
						page: true,
						skin: 'line'
					});


				} else {
					layer.alert(data.data.info);
				}
			},
			error: function(data) {
				alertHttpError();
			}
		});




		/**
		 * toolbar监听事件
		 */
		table.on('toolbar(currentTableFilter)', function(obj) {
			if (obj.event === 'add') { // 监听添加操作
				var index = layer.open({
					title: '添加',
					type: 2,
					shade: 0.2,
					maxmin: true,
					shadeClose: true,
					area: ['100%', '100%'],
					content: 'add.html',
				});
				$(window).on("resize", function() {
					layer.full(index);
				});
			}

		});


        // 监听搜索操作
        form.on('submit(data-search-btn)', function (data) {
            var result = JSON.stringify(data.field);
			
			
           var datas = {
			   "token": window.localStorage.getItem("token"),
			   "userid": window.localStorage.getItem("userid"),
			   "oid":data.field.s_oid,
			   };
           $.ajax({
           	url: baseurl + "order/getOrderOid",
           	data: JSON.stringify(datas),
           	type: "post",
           	dataType: "json",
           	headers: {
           		'Content-Type': 'application/json;charset=utf-8'
           	}, //接口json格式
           	success: function(data) {
           		if (data.code == "200") {
					
					
					var d = data.data.info;
					table.render({
						elem: '#currentTableId',
						data: d,
						toolbar: '#toolbarDemo',
						defaultToolbar: ['filter', 'exports', 'print', {
							title: '提示',
							layEvent: 'LAYTABLE_TIPS',
							icon: 'layui-icon-tips'
						}],
						cols: [
							[{
									field: 'oid',
									width: 240,
									title: '订单编号',
									templet:"<span>{{d.orders.oid}}<span>"
								},
								{
									field: 'pnum',
									width: 120,
									title: '商品数量',
									align: "center",
									templet:"<span>{{d.products.length}}<span>"
									
								},
								{
									field: 'pname',
									width: 300,
									title: '商品名称',
									align: "center",
									templet: function(data){
										var pnames = "";
										for (var i = 0; i < data.products.length; i++) {
											pnames+=data.products[i].pname+" "
										}
										return "<span>"+pnames+"</span>";
									}
								},
								{
									field: 'price',
									width: 120,
									title: '实际支付',
									align: "center",
									templet: function(data){
										var price = 0.00;
										for (var i = 0; i < data.products.length; i++) {
											price+=data.products[i].price;
										}
										return "<span>"+price+"</span>";
									}
								},
								{
									field: 'ptype',
									width: 120,
									title: '支付类型',
									align: "center",
									templet:"<span>{{d.orders.paytype}}<span>"
								},
								{
									field: 'score',
									width: 240,
									title: '日期',
									align: "center",
									templet:"<span>{{d.orders.date}}<span>"
								},
								{
									field: 'pnum',
									width: 240,
									title: '收银员',
									align: "center",
									templet:"<span>{{d.employee.ename}}<span>"
									
								},
					
								{
									title: '操作',
									minWidth: 200,
									toolbar: '#currentTableBar',
									align: "center"
								}
							]
						],
						limits: [10, 15, 20, 25, 50, 100],
						limit: d.length,
						page: true,
						skin: 'line'
					});
					
					
					
					
					
					
					
					
           		} else {
           			layer.alert(data.data.info);
           		}
           	},
           	error: function(data) {
           		alertHttpError();
           	}
           });
		   


            // //执行搜索重载
            // table.reload('currentTableId', {
            //     page: {
            //         curr: 1
            //     }
            //     , where: {
            //         pname: "我的薯片"
            //     }
            // }, 'data');

            return false;
        });
		
		




		table.on('tool(currentTableFilter)', function(obj) {
			var data = obj.data;
			if (obj.event === 'edit') {
				layer.confirm('直接点击你要编辑的字段即可实现编辑保存');
				return false;
			} else if (obj.event === 'delete') {
				// 执行删除用户操作
				layer.confirm('真的要删除这个订单吗？', function(index) {


					var datas = {
						"token": window.localStorage.getItem("token"),
						"userid": window.localStorage.getItem("userid"),
						"oid": obj.data.orders.oid
					};

					$.ajax({
						url: baseurl + "order/delOrder",
						data: JSON.stringify(datas),
						type: "post",
						dataType: "json",
						headers: {
							'Content-Type': 'application/json;charset=utf-8'
						}, //接口json格式
						success: function(data) {
							if (data.code == "200") {
								layer.msg('删除成功', function() {
									obj.del();
									layer.close(index);
								});
							} else {
								layer.alert(data.data.info);
							}
						},
						error: function(data) {
							alertHttpError();
						}
					});

				});
			}



		});




	});
}















// 添加
function add() {




	layui.use(['form',"upload"], function() {
		var form = layui.form,
			layer = layui.layer,
			upload = layui.upload,
			$ = layui.$;
			
			
			// 上传文件
			var path = ""; // 文件路径
			var code = "0"; // 操作码
			
			upload.render({
				elem: '#test10',
				url: baseurl + "public/upload" // 上传接口
					,
				done: function(res) {
					if (res.code == 200) {
						layer.msg('上传成功');
						path = res.data.file;
						code = res.code;
						layui.$('#showIconUrl').removeClass('layui-hide').find('span').text(path);
						layui.$('#uploadDemoView').removeClass('layui-hide').find('img').attr('src', res
							.data.file);
						console.log(res)
					} else {
						layer.msg('上传失败' + res.info);
					}
			
				}
			});





		var datas = {};
		// 异步加载订单类型
		$.ajax({
			url: baseurl + "product/getAllPtype",
			data: JSON.stringify(datas),
			type: "post",
			dataType: "json",
			headers: {
				'Content-Type': 'application/json;charset=utf-8'
			}, //接口json格式
			success: function(data) {
				if (data.code == "200") {
					var list = data.data.info;

					for (var i = 0; i < list.length; i++) {
						var option = document.createElement(
							"option"); // 创建添加option属性
						option.setAttribute("value", list[i].ptid); // 给option的value添加值
						option.innerText = list[i].ptname; // 打印option对应的纯文本 
						ptype.appendChild(option); //给select添加option子标签
						form.render("select"); // 刷性select，显示出数据

					}



				} else {
					layer.alert(data.data.info);
				}
			},
			error: function(data) {
				alertHttpError();
			}
		});




		var datas = {};
		// 异步加载折扣信息
		$.ajax({
			url: baseurl + "product/getAllDiscount",
			data: JSON.stringify(datas),
			type: "post",
			dataType: "json",
			headers: {
				'Content-Type': 'application/json;charset=utf-8'
			}, //接口json格式
			success: function(data) {
				if (data.code == "200") {
					var list = data.data.info;

					for (var i = 0; i < list.length; i++) {
						var option = document.createElement(
							"option"); // 创建添加option属性
						option.setAttribute("value", list[i].did); // 给option的value添加值
						option.innerText = list[i].dname + " " + list[i].val +
						"折"; // 打印option对应的纯文本 
						dtype.appendChild(option); //给select添加option子标签
						form.render("select"); // 刷性select，显示出数据
					}






					// $("#dval").val("" + list[0].val);

					//  form.on('select(dtype)', function(data){
					//       $("#dval").val("" + list[data.did].val);
					//       });




				} else {
					layer.alert(data.data.info);
				}
			},
			error: function(data) {
				alertHttpError();
			}
		});




		form.on("radio(isdiscount)", function(data) {
			var sex = data.value;
			if (this.value === 'false') {
				$("#dtypeInfo").css("display", "none");
			} else if (this.value === 'true') {
				$("#dtypeInfo").css("display", "block");
			}
		});







		//监听提交
		form.on('submit(saveBtn)', function(data) {
			var data = data.field;
			var index = layer.alert("确认添加吗???", {
				title: '确认添加'
			}, function() {
				if(code == 200){
					var datas = {
						"token": window.localStorage.getItem("token"),
						"userid": window.localStorage.getItem("userid"),
						        "pname":data.pname,
						        "img":path,
						        "price":data.price,
						        "isdiscount":data.isdiscount,
						        "did":data.dtype,
						        "ptid":data.ptype,
						        "score":data.score,
						        "pstate":data.pstate,
								"pnum":data.pnum
					};
					
					$.ajax({
						url: baseurl + "product/addProduct",
						data: JSON.stringify(datas),
						type: "post",
						dataType: "json",
						headers: {
							'Content-Type': 'application/json;charset=utf-8'
						}, //接口json格式
						success: function(data) {
							if (data.code == "200") {
								layer.msg('添加成功', function() {
									// 关闭弹出层
									layer.close(index);
					
									var iframeIndex = parent.layer
										.getFrameIndex(window.name);
									parent.layer.close(iframeIndex);
								});
							} else {
								layer.alert(data.data.info);
							}
						},
						error: function(data) {
							alertHttpError();
						}
					});
					
				}else{
					layer.alert("请先上传订单图片")
				}
			});

			return false;
		});

	});

}
