// 用户管理
function product() {

	layui.use(['form', 'table'], function() {
		var $ = layui.jquery,
			form = layui.form,
			table = layui.table;
		
		

		var datas = {
			"token": window.localStorage.getItem("token"),
			"userid": window.localStorage.getItem("userid"),
		};

		$.ajax({
			url: baseurl + "manager/getAllGoods",
			data: JSON.stringify(datas),
			type: "post",
			dataType: "json",
			headers: {
				'Content-Type': 'application/json;charset=utf-8'
			}, //接口json格式
			success: function(data) {
				if (data.code == "1") {


					var d = data.data;

					table.render({
						elem: '#currentTableId',
						data: d,
						toolbar: '#toolbarDemo',
						defaultToolbar: ['filter', 'exports', 'print', {
							title: '提示',
							layEvent: 'LAYTABLE_TIPS',
							icon: 'layui-icon-tips'
						}],
						cols: [
							[{
									field: 'id',
									width: 120,
									title: 'ID',
								},
								{
									field: 'icon',
									width: 120,
									title: '图标',
									align: "center",
									edit: 'text',
									templet:"#imgtmp"
								},
								{
									field: 'name',
									width: 120,
									title: '商品名称',
									edit: 'text',
									align: "center",
								},
								{
									field: 'type',
									title: '商品类别',
									edit: 'text',
									width:120,
									align: "center",
								},
								{
									field: 'price',
									width: 120,
									title: '售价',
									align: "center",
									edit: 'text',
								},
								{
									field: 'status',
									width: 100,
									title: '商品成色',
									align: "center",
									edit: 'text',
								},
								{
									field: 'dealtypy',
									width: 100,
									title: '交易方式',
									align: "center",
								},
								{
									field: 'contactWay',
									width: 150,
									title: '联系方式',
									align: "center",
									edit: 'text',
								},
								{
									field: 'updateTime',
									width: 200,
									title: '发布时间',
									align: "center",
								},
								
								{
									field: 'describes',
									width: 300,
									title: '描述',
									align: "center",
									edit: 'text',
								},
								{
									field: 'manage',
									width: 300,
									title: '商品状态',
									align: "center",
									edit: 'text',
									templet: function(data){
										if(data.manage == "0"){
											tmp = "发布 待审核";
											return "<span style='color:#00aaff'>"+tmp+"</span>";
										}
										if(data.manage == "1"){
											tmp = "审核通过 正常";
											return "<span style='color:#55ff7f'>"+tmp+"</span>";
										}
										if(data.manage == "2"){
											tmp = "审核不通过 未上架";
											return "<span style='color:#ff0000'>"+tmp+"</span>";
										}
										if(data.manage == "3"){
											tmp = "商品下架";
											return "<span style='color:#550000'>"+tmp+"</span>";
										}
									}
								},
								{
									title: '操作',
									minWidth: 300,
									toolbar: '#currentTableBar',
									align: "center"
								}
							]
						],
						limits: [10, 15, 20, 25, 50, 100],
						limit: d.length,
						page: true,
						skin: 'line'
					});


				} else {
					layer.alert(data.msg);
				}
			},
			error: function(data) {
				alertHttpError();
			}
		});




		/**
		 * toolbar监听事件
		 */
		table.on('toolbar(currentTableFilter)', function(obj) {
			if (obj.event === 'add') { // 监听添加操作
				var index = layer.open({
					title: '添加',
					type: 2,
					shade: 0.2,
					maxmin: true,
					shadeClose: true,
					area: ['100%', '100%'],
					content: 'add.html',
				});
				$(window).on("resize", function() {
					layer.full(index);
				});
			}

		});
		
		// 监听搜索操作
		form.on('submit(data-search-btn)', function (data) {
			console.log(data);
		   var datas = {
			   "name":data.field.sname,
			   };
		   $.ajax({
		   	url: baseurl + "manager/getGoodsByName",
		   	data: JSON.stringify(datas),
		   	type: "post",
		   	dataType: "json",
		   	headers: {
		   		'Content-Type': 'application/json;charset=utf-8'
		   	}, //接口json格式
		   	success: function(data) {
				if (data.code == "1") {
					var d = data.data;
					
					table.render({
						elem: '#currentTableId',
						data: d,
						toolbar: '#toolbarDemo',
						defaultToolbar: ['filter', 'exports', 'print', {
							title: '提示',
							layEvent: 'LAYTABLE_TIPS',
							icon: 'layui-icon-tips'
						}],
						cols: [
							[{
									field: 'id',
									width: 120,
									title: 'ID',
								},
								{
									field: 'icon',
									width: 120,
									title: '图标',
									align: "center",
									edit: 'text',
									templet:"#imgtmp"
								},
								{
									field: 'name',
									width: 120,
									title: '商品名称',
									edit: 'text',
									align: "center",
								},
								{
									field: 'type',
									title: '商品类别',
									edit: 'text',
									width:120,
									align: "center",
								},
								{
									field: 'price',
									width: 120,
									title: '售价',
									align: "center",
									edit: 'text',
								},
								{
									field: 'status',
									width: 100,
									title: '商品成色',
									align: "center",
									edit: 'text',
								},
								{
									field: 'dealtypy',
									width: 100,
									title: '交易方式',
									align: "center",
								},
								{
									field: 'contactWay',
									width: 150,
									title: '联系方式',
									align: "center",
									edit: 'text',
								},
								{
									field: 'updateTime',
									width: 200,
									title: '发布时间',
									align: "center",
								},
								
								{
									field: 'describes',
									width: 300,
									title: '描述',
									align: "center",
									edit: 'text',
								},
								{
									field: 'manage',
									width: 300,
									title: '商品状态',
									align: "center",
									edit: 'text',
									templet: function(data){
										if(data.manage == "0"){
											tmp = "发布 待审核";
											return "<span style='color:#00aaff'>"+tmp+"</span>";
										}
										if(data.manage == "1"){
											tmp = "审核通过 正常";
											return "<span style='color:#55ff7f'>"+tmp+"</span>";
										}
										if(data.manage == "2"){
											tmp = "审核不通过 未上架";
											return "<span style='color:#ff0000'>"+tmp+"</span>";
										}
										if(data.manage == "3"){
											tmp = "商品下架";
											return "<span style='color:#550000'>"+tmp+"</span>";
										}
									}
								},
								{
									title: '操作',
									minWidth: 300,
									toolbar: '#currentTableBar',
									align: "center"
								}
							]
						],
						limits: [10, 15, 20, 25, 50, 100],
						limit: d.length,
						page: true,
						skin: 'line'
					});
				
				
				} else {
					layer.alert(data.msg);
				}
				
				
		   	},
		   	error: function(data) {
		   		alertHttpError();
		   	}
		   });
		   
		
		
		
		    return false;
		});
		
		
		
		
		

		//监听单元格编辑
		table.on('edit(currentTableFilter)', function(obj) {
			var value = obj.value //得到修改后的值
				,
				data = obj.data //得到所在行所有键值
				,
				field = obj.field; //得到字段

			var datas = "{\""+ field + "\":\""+ value+"\",\"id\":\""+data.id+"\"}";

			$.ajax({
				url: baseurl + "manager/editGoods",
				data: JSON.parse(JSON.stringify(datas)),
				type: "post",
				dataType: "json",
				headers: {
					'Content-Type': 'application/json;charset=utf-8'
				}, //接口json格式
				success: function(data) {
					if (data.code == "1") {
						layer.msg('修改成功', function() {
							// obj.del();
							// layer.close(index);
							location.reload(1);
						});
					} else {
						layer.alert(data.msg);
					}
				},
				error: function(data) {
					alertHttpError();
				}
			});



		});




		table.on('tool(currentTableFilter)', function(obj) {
			var data = obj.data;
			if (obj.event === 'pass') {
				// 执行通过审核操作
				layer.confirm('确定通过吗,通过既直接上架商城？', function(index) {
				
				
					var datas = {
						"id": data.id,
						"manage": "1",
					};
				
					$.ajax({
						url: baseurl + "manager/checkGoods?id="+data.id+"&manage="+1,
						data: JSON.stringify(datas),
						type: "post",
						dataType: "json",
						headers: {
							'Content-Type': 'application/json;charset=utf-8'
						}, //接口json格式
						success: function(data) {
							if (data.code == "1") {
								layer.msg('操作成功', function() {
									location.reload(true);
								});
							} else {
								layer.alert(data.msg);
							}
						},
						error: function(data) {
							alertHttpError();
						}
					});
				
				});
				return false;
			}
			 if (obj.event === 'unpass') {
				 // 执行通过审核操作
				 layer.confirm('确定驳回吗,驳回不会显示在商城？', function(index) {
				 
				 
				 	var datas = {
				 		"id": data.id,
				 		"manage": "2",
				 	};
				 
				 	$.ajax({
				 		url: baseurl + "manager/checkGoods?id="+data.id+"&manage="+2,
				 		data: JSON.stringify(datas),
				 		type: "post",
				 		dataType: "json",
				 		headers: {
				 			'Content-Type': 'application/json;charset=utf-8'
				 		}, //接口json格式
				 		success: function(data) {
				 			if (data.code == "1") {
				 				layer.msg('操作成功', function() {
				 					location.reload(true);
				 				});
				 			} else {
				 				layer.alert(data.msg);
				 			}
				 		},
				 		error: function(data) {
				 			alertHttpError();
				 		}
				 	});
				 
				 });
				 return false;
			 } 
			 if (obj.event === 'soldout') {
				 // 执行通过审核操作
				layer.confirm('确定驳回吗,驳回不会显示在商城？', function(index) {
				
				
					var datas = {
						"id": data.id,
						"manage": "3",
					};
				
					$.ajax({
						url: baseurl + "manager/checkGoods?id="+data.id+"&manage="+3,
						data: JSON.stringify(datas),
						type: "post",
						dataType: "json",
						headers: {
							'Content-Type': 'application/json;charset=utf-8'
						}, //接口json格式
						success: function(data) {
							if (data.code == "1") {
								layer.msg('操作成功', function() {
									location.reload(true);
								});
							} else {
								layer.alert(data.msg);
							}
						},
						error: function(data) {
							alertHttpError();
						}
					});
				
				});
				return false;
			 } else if (obj.event === 'delete') {
				// 执行删除用户操作
				layer.confirm('真的要删除这个商品吗？', function(index) {


					var datas = {
						"id": data.id
					};

					$.ajax({
						url: baseurl + "manager/checkGoods",
						data: JSON.stringify(datas),
						type: "post",
						dataType: "json",
						headers: {
							'Content-Type': 'application/json;charset=utf-8'
						}, //接口json格式
						success: function(data) {
							if (data.code == "1") {
								layer.msg('删除成功', function() {
									obj.del();
									layer.close(index);
								});
							} else {
								layer.alert(data.msg);
							}
						},
						error: function(data) {
							alertHttpError();
						}
					});

				});
			}



		});




	});
}















// 添加
function add() {




	layui.use(['form',"upload"], function() {
		var form = layui.form,
			layer = layui.layer,
			upload = layui.upload,
			$ = layui.$;
			
			
			// 上传文件
			var path = ""; // 文件路径
			var code = "0"; // 操作码
			
			upload.render({
				elem: '#test10',
				url: baseurl + "public/upload" // 上传接口
					,
				done: function(res) {
					if (res.code == 200) {
						layer.msg('上传成功');
						path = res.data.file;
						code = res.code;
						layui.$('#showIconUrl').removeClass('layui-hide').find('span').text(path);
						layui.$('#uploadDemoView').removeClass('layui-hide').find('img').attr('src', res
							.data.file);
						console.log(res)
					} else {
						layer.msg('上传失败' + res.info);
					}
			
				}
			});





		var datas = {};
		// 异步加载商品类型
		$.ajax({
			url: baseurl + "product/getAllPtype",
			data: JSON.stringify(datas),
			type: "post",
			dataType: "json",
			headers: {
				'Content-Type': 'application/json;charset=utf-8'
			}, //接口json格式
			success: function(data) {
				if (data.code == "200") {
					var list = data.data.info;

					for (var i = 0; i < list.length; i++) {
						var option = document.createElement(
							"option"); // 创建添加option属性
						option.setAttribute("value", list[i].ptid); // 给option的value添加值
						option.innerText = list[i].ptname; // 打印option对应的纯文本 
						ptype.appendChild(option); //给select添加option子标签
						form.render("select"); // 刷性select，显示出数据

					}



				} else {
					layer.alert(data.data.info);
				}
			},
			error: function(data) {
				alertHttpError();
			}
		});




		var datas = {};
		// 异步加载折扣信息
		$.ajax({
			url: baseurl + "product/getAllDiscount",
			data: JSON.stringify(datas),
			type: "post",
			dataType: "json",
			headers: {
				'Content-Type': 'application/json;charset=utf-8'
			}, //接口json格式
			success: function(data) {
				if (data.code == "200") {
					var list = data.data.info;

					for (var i = 0; i < list.length; i++) {
						var option = document.createElement(
							"option"); // 创建添加option属性
						option.setAttribute("value", list[i].did); // 给option的value添加值
						option.innerText = list[i].dname + " " + list[i].val +
						"折"; // 打印option对应的纯文本 
						dtype.appendChild(option); //给select添加option子标签
						form.render("select"); // 刷性select，显示出数据
					}






					// $("#dval").val("" + list[0].val);

					//  form.on('select(dtype)', function(data){
					//       $("#dval").val("" + list[data.did].val);
					//       });




				} else {
					layer.alert(data.data.info);
				}
			},
			error: function(data) {
				alertHttpError();
			}
		});




		form.on("radio(isdiscount)", function(data) {
			var sex = data.value;
			if (this.value === 'false') {
				$("#dtypeInfo").css("display", "none");
			} else if (this.value === 'true') {
				$("#dtypeInfo").css("display", "block");
			}
		});







		//监听提交
		form.on('submit(saveBtn)', function(data) {
			var data = data.field;
			var index = layer.alert("确认添加吗???", {
				title: '确认添加'
			}, function() {
				if(code == 200){
					var datas = {
						"token": window.localStorage.getItem("token"),
						"userid": window.localStorage.getItem("userid"),
						        "pname":data.pname,
						        "img":path,
						        "price":data.price,
						        "isdiscount":data.isdiscount,
						        "did":data.dtype,
						        "ptid":data.ptype,
						        "score":data.score,
						        "pstate":data.pstate,
								"pnum":data.pnum
					};
					
					$.ajax({
						url: baseurl + "product/addProduct",
						data: JSON.stringify(datas),
						type: "post",
						dataType: "json",
						headers: {
							'Content-Type': 'application/json;charset=utf-8'
						}, //接口json格式
						success: function(data) {
							if (data.code == "200") {
								layer.msg('添加成功', function() {
									// 关闭弹出层
									layer.close(index);
					
									var iframeIndex = parent.layer
										.getFrameIndex(window.name);
									parent.layer.close(iframeIndex);
								});
							} else {
								layer.alert(data.data.info);
							}
						},
						error: function(data) {
							alertHttpError();
						}
					});
					
				}else{
					layer.alert("请先上传商品图片")
				}
			});

			return false;
		});

	});

}
