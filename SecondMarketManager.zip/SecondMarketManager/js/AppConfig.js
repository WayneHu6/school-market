// 服务器地址
var host = "localhost";
// 端口号
var port = "9088";
// 访问主接口地址
var pname = "";
// url封装
var baseurl = "http://"+host+":"+port+"/"+pname+"/";

// 服务器通讯失败提示
function alertHttpError(){
	layer.alert("与服务器通讯失败，请检查网络状态、主机地址、请求参数是否正常", {
		title: "通讯失败"
	});
}

